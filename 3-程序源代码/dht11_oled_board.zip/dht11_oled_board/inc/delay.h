#ifndef __DELAY_H_
#define __DELAY_H_

extern void delay_ms(__IO uint32 n_ms);
extern void delay_us(__IO uint32 n_us);

#endif

