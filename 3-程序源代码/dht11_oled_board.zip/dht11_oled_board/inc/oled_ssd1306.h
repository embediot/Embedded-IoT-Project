#ifndef __OLED_SSD1306_H_
#define __OLED_SSD1306_H_

#define TEXTSIZE_6X8        1
#define TEXTSIZE_8X16       2

//OLED_CS���Ŷ���
#define OLED_CS_PIN           GPIO_Pin_6
#define OLED_CS_PORT          GPIOB
#define OLED_CS_PIN_SCK       RCC_AHBPeriph_GPIOB

//OLED_DC���Ŷ���
#define OLED_DC_PIN           GPIO_Pin_7
#define OLED_DC_PORT          GPIOB
#define OLED_DC_PIN_SCK       RCC_AHBPeriph_GPIOB

//OLED_RST���Ŷ���
#define OLED_RST_PIN           GPIO_Pin_12
#define OLED_RST_PORT          GPIOA
#define OLED_RST_PIN_SCK       RCC_AHBPeriph_GPIOA

//OLED_CS���Ų���
#define OLED_CS_HIGH()         GPIO_SetBits(OLED_CS_PORT, OLED_CS_PIN)
#define OLED_CS_LOW()          GPIO_ResetBits(OLED_CS_PORT, OLED_CS_PIN)

//OLED_DC���Ų���
#define OLED_DC_HIGH()         GPIO_SetBits(OLED_DC_PORT, OLED_DC_PIN)
#define OLED_DC_LOW()          GPIO_ResetBits(OLED_DC_PORT, OLED_DC_PIN)

//OLED_RST���Ų���
#define OLED_RST_HIGH()         GPIO_SetBits(OLED_RST_PORT, OLED_RST_PIN)
#define OLED_RST_LOW()          GPIO_ResetBits(OLED_RST_PORT, OLED_RST_PIN)


#define OLED_ADDRESS	0x3C //ͨ������0R����,������0x78��0x7A������ַ -- Ĭ��0x78

/* Exported types ------------------------------------------------------------*/
typedef enum
{
  I2C_OK                                          = 0,
  I2C_FAIL                                        = 1
}I2C_Status;

/* Exported constants --------------------------------------------------------*/
#define I2C_TIMING                                0x00210507
#define I2C_TIMEOUT                               0x1000

extern void oled_ssd1306_init(void);
extern void oled_ssd1306_set_position(unsigned char x, unsigned char y);
extern void oled_ssd1306_fill(unsigned char fill_Data);
extern void oled_ssd1306_fill_row(unsigned char row_num, unsigned char text_size);
extern void oled_ssd1306_clear(void);
extern void oled_ssd1306_power_on(void);
extern void oled_ssd1306_power_off(void);
extern void oled_ssd1306_show_string(unsigned char x, unsigned char y, unsigned char ch[], unsigned char TextSize);
extern void oled_ssd1306_show_chinese(unsigned char x, unsigned char y, unsigned char N);
extern void oled_ssd1306_draw_bmp(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char BMP[]);


#endif


