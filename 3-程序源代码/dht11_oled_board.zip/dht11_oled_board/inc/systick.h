#ifndef __SYSTICK_H_
#define __SYSTICK_H_

extern void systick_init(void);

#endif

