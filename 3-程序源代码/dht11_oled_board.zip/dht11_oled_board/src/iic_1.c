#include "main.h"


static void set_iic1_sda_in(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    	
    GPIO_InitStruct.GPIO_Pin = IIC1_SDA_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP; 
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_3;
    GPIO_Init(IIC1_SDA_PORT, &GPIO_InitStruct);
}

static void set_iic1_sda_out(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    
    GPIO_InitStruct.GPIO_Pin = IIC1_SDA_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP; 
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_3;
    GPIO_Init(IIC1_SDA_PORT, &GPIO_InitStruct);
}

/***********************************************************
** function    : void iic_gpio_init(void)
** input       : 
** output      : 
** description : ��ʼ��iic gpio�˿�
** author      :
** date        :
***********************************************************/
void iic1_gpio_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    
    RCC_AHBPeriphClockCmd(IIC1_SCL_PIN_SCK, ENABLE );
    GPIO_InitStruct.GPIO_Pin = IIC1_SCL_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_3;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP; 
    GPIO_Init(IIC1_SCL_PORT, &GPIO_InitStruct);
    
    RCC_AHBPeriphClockCmd(IIC1_SDA_PIN_SCK, ENABLE );	
    GPIO_InitStruct.GPIO_Pin = IIC1_SDA_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_3;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP; 
    GPIO_Init(IIC1_SDA_PORT, &GPIO_InitStruct);
    
    GPIO_SetBits(IIC1_SCL_PORT,IIC1_SCL_PIN);  
    GPIO_SetBits(IIC1_SDA_PORT,IIC1_SDA_PIN);  
}

/***********************************************************
** function    : void iic_start(void)
** input       : 
** output      : 
** description : iic��ʼ�ź�
** author      :
** date        :
***********************************************************/
void iic1_start(void)
{
    SET_IIC1_SDA_OUT();     //sda�����
    SET_IIC1_SDA_HIGH();
    delay_us(1);
    SET_IIC1_SCL_HIGH();
    delay_us(1);
    SET_IIC1_SDA_LOW();       //START:when CLK is high,DATA change form high to low 
    delay_us(3);
    SET_IIC1_SCL_LOW();       //ǯסI2C���ߣ�׼�����ͻ�������� 
    //delay_us(1);
}

/***********************************************************
** function    : void iic_stop(void)
** input       : 
** output      : 
** description : iicֹͣ�ź�
** author      :
** date        :
***********************************************************/
void iic1_stop(void)
{
    //iic1_start();
    SET_IIC1_SDA_LOW();
    delay_us(1);
    SET_IIC1_SCL_HIGH(); 
    delay_us(3);
    SET_IIC1_SDA_HIGH();   
}

/***********************************************************
** function    : unsigned char iic_wait_ack(void)
** input       : 
** output      : 1-����Ӧ��ʧ�ܣ�0-����Ӧ��ɹ�
** description : iic�ȴ�Ӧ��
** author      :
** date        :
***********************************************************/
unsigned char iic1_wait_ack(void)
{
    unsigned char err_times = 0;

    SET_IIC1_SDA_IN();             //SDA����Ϊ����  	   
    SET_IIC1_SCL_HIGH();
    delay_us(2);	 

    while(GET_IIC1_SDA_STATE())
    {
        err_times++;
        if(err_times>250)
        {
            iic1_stop();
            return 1;
        }
    }
    SET_IIC1_SCL_LOW();           //ʱ�����0 	   
    delay_us(2);
    
    return 0;  
}

/***********************************************************
** function    : void iic_ack(void)
** input       : 
** output      : 
** description : iic����Ӧ��
** author      :
** date        :
***********************************************************/
void iic1_ack(void)
{
    //SET_IIC1_SCL_LOW(); 
    SET_IIC1_SDA_OUT();
    SET_IIC1_SDA_LOW();
    delay_us(5);
    SET_IIC1_SCL_HIGH();
    delay_us(5);
    SET_IIC1_SCL_LOW();  
}

/***********************************************************
** function    : void iic_no_ack(void)
** input       : 
** output      : 
** description : iic������Ӧ��
** author      :
** date        :
***********************************************************/
void iic1_no_ack(void)
{
    //SET_IIC1_SCL_LOW();
    SET_IIC1_SDA_OUT();
    SET_IIC1_SDA_HIGH();
    delay_us(5);
    SET_IIC1_SCL_HIGH();
    delay_us(5);
    SET_IIC1_SCL_LOW();  
}

/***********************************************************
** function    : void iic_send_byte(unsigned char byte)
** input       : byte-Ҫ���͵��ֽ�
** output      : 
** description : iic����һ���ֽ�
** author      :
** date        :
***********************************************************/
void iic1_send_byte(unsigned char byte)
{ 
    unsigned char i;
    SET_IIC1_SDA_OUT();
    
    for(i=0;i<8;i++)
    {
        SET_IIC1_SCL_LOW();  
        if(byte & 0x80)
            SET_IIC1_SDA_HIGH();
        else
            SET_IIC1_SDA_LOW();
        
        byte <<= 1;
        delay_us(1);
        SET_IIC1_SCL_HIGH();
        delay_us(1);      
    }
    //iic1_wait_ack();
    SET_IIC1_SCL_LOW();  
    delay_us(1);
    SET_IIC1_SDA_HIGH();
    delay_us(1);
    SET_IIC1_SCL_HIGH();
    delay_us(1);
    SET_IIC1_SCL_LOW();
    delay_us(1);
}

/***********************************************************
** function    : void iic_send_byte(unsigned char byte)
** input       : ack_flag-1������ack��0-����nack
** output      : ���ض�ȡ���ֽ�
** description : iic��ȡһ���ֽ�
** author      :
** date        :
***********************************************************/
unsigned char iic1_read_byte(void)
{
    unsigned char i,receive = 0;

    SET_IIC1_SDA_IN();       //SDA����Ϊ����

    for(i=0;i<8;i++)
    {         
        SET_IIC1_SCL_HIGH();
        receive <<= 1;
        if(GET_IIC1_SDA_STATE())receive++;   
        SET_IIC1_SCL_LOW(); 
        delay_us(5); 
    }

//    if (!ack_flag)iic_no_ack();          //����nACK
//    else iic_ack();                      //����ACK   

    return receive;
}



