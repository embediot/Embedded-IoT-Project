#ifndef __EPD2IN13_H_
#define __EPD2IN13_H_

#define EPD_CS_PIN             GPIO_Pin_4
#define EPD_CS_PORT            GPIOA
#define EPD_CS_PIN_SCK         RCC_AHBPeriph_GPIOA

#define EPD_RST_PIN            GPIO_Pin_15
#define EPD_RST_PORT           GPIOA
#define EPD_RST_PIN_SCK        RCC_AHBPeriph_GPIOA

#define EPD_DC_PIN             GPIO_Pin_8
#define EPD_DC_PORT            GPIOA
#define EPD_DC_PIN_SCK         RCC_AHBPeriph_GPIOA

#define EPD_BUSY_PIN           GPIO_Pin_12
#define EPD_BUSY_PORT          GPIOA
#define EPD_BUSY_PIN_SCK       RCC_AHBPeriph_GPIOA



#define EPD_CS_LOW()          GPIO_ResetBits(EPD_CS_PORT, EPD_CS_PIN)
#define EPD_CS_HIGH()         GPIO_SetBits(EPD_CS_PORT, EPD_CS_PIN)

#define EPD_RST_LOW()          GPIO_ResetBits(EPD_RST_PORT, EPD_RST_PIN)
#define EPD_RST_HIGH()         GPIO_SetBits(EPD_RST_PORT, EPD_RST_PIN)

#define EPD_DC_LOW()           GPIO_ResetBits(EPD_DC_PORT, EPD_DC_PIN)
#define EPD_DC_HIGH()          GPIO_SetBits(EPD_DC_PORT, EPD_DC_PIN)

#define EPD_BUSY_LEVEL()       GPIO_ReadInputDataBit(EPD_BUSY_PORT, EPD_BUSY_PIN)

#define EPD2IN13_SPI_READ_WRITE_BYTE(byte)    spi1_send_byte(byte)
// Display resolution
#define EPD_WIDTH       128
#define EPD_HEIGHT      250

// EPD2IN13 commands
#define DRIVER_OUTPUT_CONTROL                       0x01
#define BOOSTER_SOFT_START_CONTROL                  0x0C
#define GATE_SCAN_START_POSITION                    0x0F
#define DEEP_SLEEP_MODE                             0x10
#define DATA_ENTRY_MODE_SETTING                     0x11
#define SW_RESET                                    0x12
#define TEMPERATURE_SENSOR_CONTROL                  0x1A
#define MASTER_ACTIVATION                           0x20
#define DISPLAY_UPDATE_CONTROL_1                    0x21
#define DISPLAY_UPDATE_CONTROL_2                    0x22
#define WRITE_RAM                                   0x24
#define WRITE_VCOM_REGISTER                         0x2C
#define WRITE_LUT_REGISTER                          0x32
#define SET_DUMMY_LINE_PERIOD                       0x3A
#define SET_GATE_TIME                               0x3B
#define BORDER_WAVEFORM_CONTROL                     0x3C
#define SET_RAM_X_ADDRESS_START_END_POSITION        0x44
#define SET_RAM_Y_ADDRESS_START_END_POSITION        0x45
#define SET_RAM_X_ADDRESS_COUNTER                   0x4E
#define SET_RAM_Y_ADDRESS_COUNTER                   0x4F
#define TERMINATE_FRAME_READ_WRITE                  0xFF



extern const unsigned char lut_full_update[];
extern const unsigned char lut_partial_update[];



extern void epd2in13_sleep(void);
extern void epd2in13_reset(void);
extern void epd2in13_init(const unsigned char *types_of_lut);
extern void epd2in13_set_frame_memory(const unsigned char* image_buffer,int x,int y,int image_width,int image_height);
extern void epd2in13_clear_frame_memory(unsigned char color);
extern void epd2in13_display_frame(void);

#endif


