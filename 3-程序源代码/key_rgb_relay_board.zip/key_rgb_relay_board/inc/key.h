#ifndef __KEY_H_
#define __KEY_H_



/** RESET KEY Ӳ���ӿڶ��� */
#define RESET_KEY_PIN               GPIO_Pin_6
#define RESET_KEY_PORT              GPIOF
#define RESET_KEY_PIN_SCK           RCC_AHBPeriph_GPIOF
#define RESET_KEY_EXTI_PORT_SRC     EXTI_PortSourceGPIOF
#define RESET_KEY_EXTI_PIN_SRC      EXTI_PinSource6
#define RESET_KEY_EXTI_LINE         EXTI_Line6
#define RESET_KEY_IRQ_CHANNEL       EXTI4_15_IRQn
#define RESET_KEY_IRQ_HANDLER       EXTI4_15_IRQHandler 


/** USER KEY Ӳ���ӿڶ��� */
#define USER_KEY1_PIN               GPIO_Pin_3
#define USER_KEY1_PORT              GPIOB
#define USER_KEY1_PIN_SCK           RCC_AHBPeriph_GPIOB
#define USER_KEY1_EXTI_PORT_SRC     EXTI_PortSourceGPIOB
#define USER_KEY1_EXTI_PIN_SRC      EXTI_PinSource3
#define USER_KEY1_EXTI_LINE         EXTI_Line3
#define USER_KEY1_IRQ_CHANNEL       EXTI2_3_IRQn
#define USER_KEY1_IRQ_HANDLER       EXTI2_3_IRQHandler 


#define USER_KEY2_PIN               GPIO_Pin_4
#define USER_KEY2_PORT              GPIOB
#define USER_KEY2_PIN_SCK           RCC_AHBPeriph_GPIOB
#define USER_KEY2_EXTI_PORT_SRC     EXTI_PortSourceGPIOB
#define USER_KEY2_EXTI_PIN_SRC      EXTI_PinSource4
#define USER_KEY2_EXTI_LINE         EXTI_Line4
#define USER_KEY2_IRQ_CHANNEL       EXTI4_15_IRQn
#define USER_KEY2_IRQ_HANDLER       EXTI4_15_IRQHandler 


#define USER_KEY3_PIN               GPIO_Pin_5
#define USER_KEY3_PORT              GPIOB
#define USER_KEY3_PIN_SCK           RCC_AHBPeriph_GPIOB
#define USER_KEY3_EXTI_PORT_SRC     EXTI_PortSourceGPIOB
#define USER_KEY3_EXTI_PIN_SRC      EXTI_PinSource5
#define USER_KEY3_EXTI_LINE         EXTI_Line5
#define USER_KEY3_IRQ_CHANNEL       EXTI4_15_IRQn
#define USER_KEY3_IRQ_HANDLER       EXTI4_15_IRQHandler 





extern void key_gpio_init(void);

#endif
