#ifndef __NRF24L01_TASK_H_
#define __NRF24L01_TASK_H_



#define NRF24L01_TASK_START_EVENT   0x0001        
#define NRF24L01_SEND_DATA_EVENT    0x0002






#define NRF24L01_TASK_START_PERIOD    1000   





extern unsigned char nrf24l01_tx_finish_flag;













extern unsigned char nrf24l01_send_data(unsigned char *p_data,unsigned int len);
extern void nrf24l01_task_init(void);


#endif


