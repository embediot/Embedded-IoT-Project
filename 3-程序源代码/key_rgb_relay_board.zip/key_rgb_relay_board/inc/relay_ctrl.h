#ifndef RELAY_CTRL_H
#define RELAY_CTRL_H



//�̵������Ŷ���
#define RELAY_CTRL_PIN           GPIO_Pin_7
#define RELAY_CTRL_PORT          GPIOF
#define RELAY_CTRL_PIN_SCK       RCC_AHBPeriph_GPIOF


//�̵������Ų���
#define RELAY_CTRL_ON()          GPIO_ResetBits(RELAY_CTRL_PORT, RELAY_CTRL_PIN)
#define RELAY_CTRL_OFF()         GPIO_SetBits(RELAY_CTRL_PORT, RELAY_CTRL_PIN)



extern void relay_ctrl_gpio_init(void);


#endif


