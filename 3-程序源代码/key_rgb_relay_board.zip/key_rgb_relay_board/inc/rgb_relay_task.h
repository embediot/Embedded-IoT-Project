#ifndef RGB_RELAY_TASK_H
#define RGB_RELAY_TASK_H


#define RGB_RELAY_TASK_START_EVENT    0x0001     //�������������¼�

#define PWM_DUTY_BASE            10

typedef enum
{
    RED_LED_CHANNEL,
    GREEN_LED_CHANNEL,
    BLUE_LED_CHANNEL,
    ALL_LED_CHANNEL,
}led_channel_t;




extern void rgb_relay_task_init(void);






#endif

