#ifndef __TIMER_H_
#define __TIMER_H_

extern unsigned char  TIM1CH1_CAPTURE_STA;	    //���벶��״̬		    				
extern unsigned short TIM1CH1_CAPTURE_VAL;	    //���벶��ֵ(TIM1)




extern void timer1_cap_init(unsigned short arr,unsigned short psc);
extern void timer3_int_init(unsigned short arr,unsigned short psc);
extern void timer3_pwm_init(unsigned short arr,unsigned short psc);
extern void timer1_pwm_init(unsigned short arr,unsigned short psc);
#endif

