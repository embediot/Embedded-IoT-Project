#ifndef __USART_DMA_H_
#define __USART_DMA_H_

#ifdef USART_DMA


#ifdef USART1_ON
#define USART1_RDR_BASE  (USART1_BASE+0x24)  //0x40013824
#define USART1_TDR_BASE  (USART1_BASE+0x28)  //0x40013828

#define MAX_USART1_RX_LEN      256   //���ڵ���������������

extern uchar usart1_rx_buff[MAX_USART1_RX_LEN];
extern volatile uint16 USART1_RX_STATE;

extern void usart1_init(uint16_t baudrate);
extern uchar usart1_send_data(uchar *p_data,uint16 len);
#endif


#ifdef USART2_ON

#define USART2_RDR_BASE  (USART2_BASE+0x24)  //0x40004424
#define USART2_TDR_BASE  (USART2_BASE+0x28)  //0x40004428

#define MAX_USART2_RX_LEN      256   //���ڵ���������������




extern uchar usart2_rx_buff[MAX_USART2_RX_LEN];
extern volatile uint16 USART2_RX_STATE;

extern void usart2_init(uint16_t baudrate);
extern uchar usart2_send_data(uchar *p_data,uint16 len);
#endif












#endif



#endif


