#include "main.h"


void EXTI0_1_IRQHandler(void)
{
    if ( EXTI_GetITStatus(SI4432_EXTI_LINE) != RESET )     //si4432�ж�
    {	
        si4432_irq_process();
        osal_set_event( SI4432_TASK_ID, SI4432_IRQ_PROCESS_EVENT );   //�жϴ����¼�
        EXTI_ClearITPendingBit(SI4432_EXTI_LINE);
    }
}


void EXTI2_3_IRQHandler(void)
{
    if ( EXTI_GetITStatus(USER_KEY1_EXTI_LINE) != RESET )     //USER KEY1�����ж�
    {	
        nrf24l01_send_data(">>> user key1 press >>>\n",sizeof(">>> user key1 press >>>\n"));
        EXTI_ClearITPendingBit(USER_KEY1_EXTI_LINE);
    }
}


//�ⲿ�жϴ�������
void EXTI4_15_IRQHandler(void)
{
    if ( EXTI_GetITStatus(NRF24L01_EXTI_LINE) != RESET )     //nrf24l01�ж�
    {	
        nrf24l01_irq_process();
        //osal_set_event( SI4432_TASK_ID, SI4432_IRQ_PROCESS_EVENT );   //�жϴ����¼�
        EXTI_ClearITPendingBit(NRF24L01_EXTI_LINE);
    }
    
    if ( EXTI_GetITStatus(RESET_KEY_EXTI_LINE) != RESET )     //RESET�����ж�
    {	
        nrf24l01_send_data(">>> reset key press >>>\n",sizeof(">>> reset key press >>>\n"));
        EXTI_ClearITPendingBit(RESET_KEY_EXTI_LINE);
    }
    
    if ( EXTI_GetITStatus(USER_KEY2_EXTI_LINE) != RESET )     //USER KEY2�����ж�
    {	
        nrf24l01_send_data(">>> user key2 press >>>\n",sizeof(">>> user key2 press >>>\n"));
        EXTI_ClearITPendingBit(USER_KEY2_EXTI_LINE);
    }
    
    if ( EXTI_GetITStatus(USER_KEY3_EXTI_LINE) != RESET )     //USER KEY3�����ж�
    {	
        nrf24l01_send_data(">>> user key3 press >>>\n",sizeof(">>> user key3 press >>>\n"));
        EXTI_ClearITPendingBit(USER_KEY3_EXTI_LINE);
    }
}