#include "main.h"


void EXTI0_1_IRQHandler(void)
{
    if ( EXTI_GetITStatus(SI4432_EXTI_LINE) != RESET )     //si4432�ж�
    {	
        si4432_irq_process();
        //osal_set_event( SI4432_TASK_ID, SI4432_IRQ_PROCESS_EVENT );   //�жϴ����¼�
        EXTI_ClearITPendingBit(SI4432_EXTI_LINE);
    }
}





//�ⲿ�жϴ�������
void EXTI4_15_IRQHandler(void)
{
    if ( EXTI_GetITStatus(NRF24L01_EXTI_LINE) != RESET )     //nrf24l01�ж�
    {	
        nrf24l01_irq_process();
        EXTI_ClearITPendingBit(NRF24L01_EXTI_LINE);
    }
    
    if ( EXTI_GetITStatus(RESET_KEY_EXTI_LINE) != RESET )     //�����ж�
    {	
        //usart1_send_data(">>> reset key press >>>\n",sizeof(">>> reset key press >>>\n"));    //���ڷ�������
        EXTI_ClearITPendingBit(RESET_KEY_EXTI_LINE);
    }
}