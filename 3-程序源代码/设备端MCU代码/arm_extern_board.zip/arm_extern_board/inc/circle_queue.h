#ifndef __CIRCLE_QUEUE_H_
#define __CIRCLE_QUEUE_H_


//���ζ��нṹ��
#define   MAX_BUFF_LEN            256    //���ζ��л���������
typedef struct str_queue   
{
    unsigned int    sem_value;
    unsigned int    read_pos;
    unsigned int    write_pos;
    unsigned char   data[MAX_BUFF_LEN];
}str_queue_t;
//End




//�ⲿ���ú���
extern void circlebuff_init(str_queue_t *p_queue);
extern unsigned int circlebuff_read_packet_data(str_queue_t *p_queue,unsigned char *p_data);
extern unsigned char circlebuff_write_packet_data(str_queue_t *p_queue,unsigned char *s, unsigned int len);
//End




#endif


