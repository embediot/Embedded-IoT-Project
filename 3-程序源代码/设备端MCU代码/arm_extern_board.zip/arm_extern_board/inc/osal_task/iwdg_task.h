#ifndef __IWDG_TASK_H_
#define __IWDG_TASK_H_

#define IWDG_TASK_START_EVENT   0x0001     
#define IWDG_FEED_EVENT         0x0002    
#define IWDG_RESET_EVENT        0x0004

#define IWDG_FEED_PERIOD        500        //��ʱι������
#define IWDG_RESET_PERIOD       1000       //���Ź���λʱ��

extern void iwdg_task_init(void);

#endif

