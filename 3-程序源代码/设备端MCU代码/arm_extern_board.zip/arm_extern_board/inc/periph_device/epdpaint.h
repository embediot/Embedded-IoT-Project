#ifndef EPDPAINT_H
#define EPDPAINT_H

#include "fonts.h"


// Display orientation
#define ROTATE_0            0
#define ROTATE_90           1
#define ROTATE_180          2
#define ROTATE_270          3

// Color inverse. 1 or 0 = set or reset a bit if set a colored pixel
#define IF_INVERT_COLOR     1

#define COLORED      0
#define UNCOLORED    1


typedef struct str_paint 
{
    unsigned char* image;
    int width;
    int height;
    int rotate;
} paint_t;

extern void paint_init(paint_t* paint, unsigned char* image, int width, int height);
extern void paint_clear(paint_t* paint, int colored);
extern int  paint_get_width(paint_t* paint);
extern void paint_set_width(paint_t* paint, int width);
extern int  paint_get_height(paint_t* paint);
extern void paint_set_height(paint_t* paint, int height);
extern int  paint_get_rotate(paint_t* paint);
extern void paint_set_rotate(paint_t* paint, int rotate);
extern unsigned char* paint_get_image(paint_t* paint);
extern void paint_draw_absolute_pixel(paint_t* paint, int x, int y, int colored);
extern void paint_draw_pixel(paint_t* paint, int x, int y, int colored);
extern void paint_draw_char_at(paint_t* paint, int x, int y, char ascii_char, sFONT* font, int colored);
extern void paint_draw_string_at(paint_t* paint, int x, int y, const char* text, sFONT* font, int colored);
extern void paint_draw_line(paint_t* paint, int x0, int y0, int x1, int y1, int colored);
extern void paint_draw_horizontal_line(paint_t* paint, int x, int y, int width, int colored);
extern void paint_draw_vertical_line(paint_t* paint, int x, int y, int height, int colored);
extern void paint_draw_rectangle(paint_t* paint, int x0, int y0, int x1, int y1, int colored);
extern void paint_draw_filled_rectangle(paint_t* paint, int x0, int y0, int x1, int y1, int colored);
extern void paint_draw_circle(paint_t* paint, int x, int y, int radius, int colored);
extern void paint_draw_filled_circle(paint_t* paint, int x, int y, int radius, int colored);

#endif

/* END OF FILE */

