#ifndef __MAIN_H_
#define __MAIN_H_

//periph_device include
#include "stm32f0xx.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "mytype.h"
#include "usart.h"
#include "usart_dma.h"
#include "delay.h"
#include "timer.h"
#include "circle_queue.h"
#include "systick.h"
#include "flash.h"
#include "sys_config.h"
#include "myprotocol.h"
#include "spi.h"
#include "spi_dma.h"
#include "nrf24l01.h"
#include "si4432.h"
#include "led.h"
#include "key.h"
#include "tool_func.h"
#include "math.h"

//netlib include 
#include "net_module.h"


//osal include
#include "osal.h"
#include "osal_timers.h"
#include "osal_clock.h"

//osal_task include
#include "iwdg_task.h"
#include "led_task.h"
#include "usart1_task.h"
#include "usart2_task.h"
#include "nrf24l01_task.h"
#include "si4432_task.h"
#include "net_task.h"

#endif

