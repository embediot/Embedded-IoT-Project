#ifndef __MYTYPE_H_
#define __MYTYPE_H_

typedef unsigned char   uchar , uint8 ,u8;
typedef unsigned short  uint16 , u16;
typedef unsigned int    uint32 , u32;
typedef unsigned long   ulong;

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef NULL
#define NULL 0
#endif



#endif