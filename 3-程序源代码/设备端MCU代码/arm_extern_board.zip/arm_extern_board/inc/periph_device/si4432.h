#ifndef __SI4432_H_
#define __SI4432_H_


#define MASTER_DEVICE_ID        0xFEFE


//����������
#define TX_BUFFER_LEN            64 
#define RX_BUFFER_LEN            64     //����RF4432���ݰ�����

//si4432����״̬
#define SI4432_READY_STATUS        0x01
#define SI4432_RX_STATUS           0x02
#define SI4432_TX_STATUS           0x03
#define SI4432_SLEEP_STATUS        0x04

//CS ���Ŷ���
#define SI4432_CS_PIN              GPIO_Pin_4
#define SI4432_CS_PORT             GPIOA
#define SI4432_CS_PIN_SCK          RCC_AHBPeriph_GPIOA

#define SI4432_SET_CS_LOW()        GPIO_ResetBits(SI4432_CS_PORT, SI4432_CS_PIN)
#define SI4432_SET_CS_HIGH()       GPIO_SetBits(SI4432_CS_PORT, SI4432_CS_PIN)

//SDN ���Ŷ���
#define SI4432_SDN_PIN             GPIO_Pin_0
#define SI4432_SDN_PORT            GPIOA
#define SI4432_SDN_PIN_SCK         RCC_AHBPeriph_GPIOA

#define SI4432_SET_SDN_LOW()       GPIO_ResetBits(SI4432_SDN_PORT, SI4432_SDN_PIN)
#define SI4432_SET_SDN_HIGH()      GPIO_SetBits(SI4432_SDN_PORT, SI4432_SDN_PIN)

//IRQ���Ŷ���
#define SI4432_IRQ_PIN           GPIO_Pin_1
#define SI4432_IRQ_PORT          GPIOA
#define SI4432_IRQ_PIN_SCK       RCC_AHBPeriph_GPIOA
#define SI4432_EXTI_PORT_SRC     EXTI_PortSourceGPIOA
#define SI4432_EXTI_PIN_SRC      EXTI_PinSource1
#define SI4432_EXTI_LINE         EXTI_Line1
#define SI4432_IRQ_CHANNEL       EXTI0_1_IRQn
#define SI4432_IRQ_HANDLER       EXTI0_1_IRQHandler 


#define SI4432_SPI_SEND_BYTE(byte)  spi1_send_byte(byte);

extern void si4432_tx_packet(uint8_t *p_databuff,uint16_t datalen);
extern void si4432_init(void);
extern void si4432_irq_process(void);  
extern uint8_t si4432_get_rssi(void);    
extern uint8_t si4432_get_status(void);
extern uint8_t si4432_convert_channel(uint8_t channel);
#endif
