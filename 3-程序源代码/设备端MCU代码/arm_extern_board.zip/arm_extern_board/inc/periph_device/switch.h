#ifndef __SWITCH_H_
#define __SWITCH_H_

#define SWITCH_PORTA               GPIOA
#define SWITCH_PORTB               GPIOB

#define AREA_SWITCH_PIN0           GPIO_Pin_0
#define AREA_SWITCH_PIN1           GPIO_Pin_1

#define ADDR_SWITCH_PIN0           GPIO_Pin_15
#define ADDR_SWITCH_PIN1           GPIO_Pin_3
#define ADDR_SWITCH_PIN2           GPIO_Pin_4
#define ADDR_SWITCH_PIN3           GPIO_Pin_5
#define ADDR_SWITCH_PIN4           GPIO_Pin_6
#define ADDR_SWITCH_PIN5           GPIO_Pin_7
#define ADDR_SWITCH_PIN6           GPIO_Pin_8
#define ADDR_SWITCH_PIN7           GPIO_Pin_9

extern void switch_gpio_init(void);
extern unsigned short get_switch_value(void);



#endif
