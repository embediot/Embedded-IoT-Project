#ifndef __TOOL_FUNC_H_
#define __TOOL_FUNC_H_


extern int recurbinary(int *a, int key, int low, int high);
extern int binary(const float a[][2], float key, int n );
extern char* my_itoa(int value,char *str,int radix);
extern char *my_ftoa(double number,int ndigit,char *buf);
extern unsigned char str_cmp(unsigned char *p1,unsigned char *p2,unsigned char len);
extern unsigned int str_to_num(unsigned char* p_str, unsigned char len);

#endif

