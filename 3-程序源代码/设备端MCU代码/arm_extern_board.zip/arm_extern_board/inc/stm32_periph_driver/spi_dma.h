#ifndef __SPI_DMA_H_
#define __SPI_DMA_H_

#ifdef SPI_DMA

#ifdef SPI1_ON

#define SPI1_SCK_PIN           GPIO_Pin_5
#define SPI1_SCK_PORT          GPIOA
#define SPI1_SCK_PIN_SCK       RCC_AHBPeriph_GPIOA
#define SPI1_SCK_SOURCE        GPIO_PinSource5
#define SPI1_SCK_AF            GPIO_AF_0

#define SPI1_MISO_PIN          GPIO_Pin_6
#define SPI1_MISO_PORT         GPIOA
#define SPI1_MISO_PIN_SCK      RCC_AHBPeriph_GPIOA
#define SPI1_MISO_SOURCE       GPIO_PinSource6
#define SPI1_MISO_AF           GPIO_AF_0

#define SPI1_MOSI_PIN          GPIO_Pin_7
#define SPI1_MOSI_PORT         GPIOA
#define SPI1_MOSI_PIN_SCK      RCC_AHBPeriph_GPIOA
#define SPI1_MOSI_SOURCE       GPIO_PinSource7
#define SPI1_MOSI_AF           GPIO_AF_0

#define SPI1_RCC               RCC_APB2Periph_SPI1

extern void spi1_init(void);
extern unsigned char spi1_send_byte(unsigned char byte);

#endif


#ifdef SPI2_ON

#define SPI2_SCK_PIN           GPIO_Pin_13
#define SPI2_SCK_PORT          GPIOB
#define SPI2_SCK_PIN_SCK       RCC_AHBPeriph_GPIOB
#define SPI2_SCK_SOURCE        GPIO_PinSource13
#define SPI2_SCK_AF            GPIO_AF_0

#define SPI2_MISO_PIN          GPIO_Pin_14
#define SPI2_MISO_PORT         GPIOB
#define SPI2_MISO_PIN_SCK      RCC_AHBPeriph_GPIOB
#define SPI2_MISO_SOURCE       GPIO_PinSource14
#define SPI2_MISO_AF           GPIO_AF_0

#define SPI2_MOSI_PIN          GPIO_Pin_15
#define SPI2_MOSI_PORT         GPIOB
#define SPI2_MOSI_PIN_SCK      RCC_AHBPeriph_GPIOB
#define SPI2_MOSI_SOURCE       GPIO_PinSource15
#define SPI2_MOSI_AF           GPIO_AF_0


#define SPI2_RCC               RCC_APB1Periph_SPI2

extern void spi2_init(void);
extern unsigned char spi2_send_byte(unsigned char byte);

#endif


#endif





#endif


