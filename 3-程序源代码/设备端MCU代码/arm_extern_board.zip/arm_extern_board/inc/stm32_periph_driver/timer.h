#ifndef __TIMER_H_
#define __TIMER_H_

extern u8  TIM1CH1_CAPTURE_STA;	    //���벶��״̬		    				
extern u16 TIM1CH1_CAPTURE_VAL;	    //���벶��ֵ(TIM1)

extern void timer1_cap_init(u16 arr,u16 psc);
extern void timer3_int_init(u16 arr,u16 psc);

#endif

