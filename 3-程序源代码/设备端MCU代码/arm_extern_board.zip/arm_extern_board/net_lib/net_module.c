#include "main.h"


//ATָ���
void at_cmd_handle(unsigned char *p_data,unsigned char length)
{
    char str_temp[64];
    
    memset(str_temp,0x00,sizeof(str_temp));
    
    if((length == 4) && str_cmp(p_data, "AT\r\n", 4))      //����ATָ����ģ��Ĵ���ͨ���Ƿ�ɹ���
    {
        sprintf(str_temp, "AT+OK\r\n");
        usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp)); 
    }
    else if((length == 9) && str_cmp(p_data, "AT+VERS", 7))   //��ѯ�汾��Ϣ
    {
        strcat(str_temp, "software:");
        strcat(str_temp, SOFTWARE_VERSION);
        strcat(str_temp, "  hardware:");
        strcat(str_temp, HARDWARE_VERSION);
        strcat(str_temp, "\r\n");
        usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp)); 
    }
    else if((length == 11) && str_cmp(p_data, "AT+REBOOT", 9))   //����ģ��
    {
        sprintf(str_temp, "OK+REBOOT\r\n");
        usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp)); 
        
        osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , 1000 , 0 );
    }
    else if((length == 10) && str_cmp(p_data, "AT+RESET", 8))     //��λָ�����ģ����и�λ��
    {      
        set_default_sys_config();
        sprintf(str_temp, "OK+RESET\r\n");
        usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp)); 
        osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , 1000 , 0 );
    }
    else if((length == 10 ) && str_cmp(p_data, "AT+BAUD", 7))    //�޸Ĵ��ڲ�����ָ��
    {
        unsigned char ret = 0;
        unsigned int baud_value = 0;
 
        if(p_data[7] == '?')   //��ѯ��ǰ������
        {
            switch(sys_config.baudrate)
            {
                case BAUDRATE_9600:
                  sprintf(str_temp, "OK+GET:1\r\n");   
                  ret = 1; 
                break;
                  
                case BAUDRATE_19200:
                  sprintf(str_temp, "OK+GET:2\r\n");
                  ret = 1;
                break;
                
                case BAUDRATE_38400:
                  sprintf(str_temp, "OK+GET:3\r\n");
                  ret = 1;
                break;
                
                case BAUDRATE_115200:
                  sprintf(str_temp, "OK+GET:4\r\n");
                  ret = 1;
                break;
                                
                default:
                     
                break;
            }
            
            if(ret)usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp));                    
        }
        else   //���õ�ǰ������
        {
            baud_value = str_to_num(&p_data[7],1);            
                        
            if(baud_value == BAUDRATE_9600)sprintf(str_temp, "OK+SET:1\r\n");
            else if(baud_value == BAUDRATE_19200)sprintf(str_temp, "OK+SET:2\r\n");
            else if(baud_value == BAUDRATE_38400)sprintf(str_temp, "OK+SET:3\r\n");
            else if(baud_value == BAUDRATE_115200)sprintf(str_temp, "OK+SET:4\r\n");
            else sprintf(str_temp, "ERR_BAUD\r\n"); 
            
            if((baud_value < BAUDRATE_NONE) && baud_value)
            {
                sys_config.baudrate = baud_value;
                save_sys_config(&sys_config);
            }
            else {}
            
            usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp));     
            osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , 1000 , 0 );
        }
    }
    else if((length == 9 ) && str_cmp(p_data, "AT+CHN", 6))    //��ѯ/����ģ��ͨ���ŵ�
    {
        unsigned char ret = 0;
        unsigned int channel = 0;
 
        if(p_data[6] == '?')   //��ѯ��ǰ������
        {
            switch(sys_config.channel)
            {                                
                case CHANNEL_ONE:
                  sprintf(str_temp, "OK+GET:1\r\n");
                  ret = 1;
                break;
                
                case CHANNEL_TWO:
                  sprintf(str_temp, "OK+GET:2\r\n");
                  ret = 1;
                break;
                
                case CHANNEL_THREE:
                  sprintf(str_temp, "OK+GET:3\r\n");
                  ret = 1;
                break;
                     
                case CHANNEL_FOUR:
                  sprintf(str_temp, "OK+GET:4\r\n");   
                  ret = 1; 
                break;
                
                default:
                     
                break;
            }
            
            if(ret)usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp));                    
        }
        else   //���õ�ǰ������
        {
            channel = str_to_num(&p_data[6],1);            
                       
            if(channel == CHANNEL_ONE)sprintf(str_temp, "OK+SET:1\r\n");
            else if(channel == CHANNEL_TWO)sprintf(str_temp, "OK+SET:2\r\n");
            else if(channel == CHANNEL_THREE)sprintf(str_temp, "OK+SET:3\r\n");
            else if(channel == CHANNEL_FOUR)sprintf(str_temp, "OK+SET:4\r\n");
            else sprintf(str_temp, "ERR_CHANNEL\r\n"); 
            
            if((channel < CHANNEL_ALL) && channel)
            {
                sys_config.channel = channel;
                save_sys_config(&sys_config);
            }
            
            usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp));     
            osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , 1000 , 0 );
        }
    }
    else if((length == 9 ) && str_cmp(p_data, "AT+PHY", 6))    //��ѯ/���õ�ǰͨ��ģ��
    {
        unsigned char ret = 0;
        unsigned int dev_phy = 0;
 
        if(p_data[6] == '?')   //��ѯ��ǰģ��
        {
            switch(sys_config.dev_phy)
            {
                case PHY_433MHZ_MODULE:
                  sprintf(str_temp, "OK+GET:1\r\n");   
                  ret = 1; 
                break;
                  
                case PHY_2_4GHZ_MODULE:
                  sprintf(str_temp, "OK+GET:2\r\n");
                  ret = 1;
                break;
                                                           
                default:break;
            }
            
            if(ret)usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp));                    
        }
        else   //���õ�ǰģ��
        {
            dev_phy = str_to_num(&p_data[6],1);                        
            
            if(dev_phy == PHY_433MHZ_MODULE)sprintf(str_temp, "OK+SET:1\r\n");
            else if(dev_phy == PHY_2_4GHZ_MODULE)sprintf(str_temp, "OK+SET:2\r\n");
            else sprintf(str_temp, "ERR_DEV_PHY\r\n"); 
            
            if((dev_phy < PHY_ALL_MODULE) && dev_phy)
            {
                sys_config.dev_phy = dev_phy;
                save_sys_config(&sys_config);
            }
            usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp));     
            osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , 1000 , 0 );
        }
    }
    else if((length == 9 ) && str_cmp(p_data, "AT+SCAN", 7))    //����ɨ��
    {
        sprintf(str_temp, "OK+SCAN\r\n");
        usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp)); 
        osal_start_timer( NET_TASK_ID , NET_TASK_START_SCAN_EVENT , 1000 , 0 );    //1�������ɨ��
    }
    else   //ָ���ʽ���󣬷��� ERROR
    {
        usart1_send_package_data("ERROR CMD\r\n",11); 
    }
    
}

unsigned char net_module_init(void)
{
    return 0;
}

void net_module_uninit(void)
{
    
}