#include "main.h"


//ATָ���
void at_cmd_handle(unsigned char *p_data,unsigned char length)
{
    char str_temp[64];
    
    memset(str_temp,0x00,sizeof(str_temp));
    
    if((length == 4) && str_cmp(p_data, "AT\r\n", 4))      //����ATָ����ģ��Ĵ���ͨ���Ƿ�ɹ���
    {
        sprintf(str_temp, "AT+OK\r\n");
        usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp)); 
    }
    else if((length == 9) && str_cmp(p_data, "AT+VERS", 7))   //��ѯ�汾��Ϣ
    {
        
    }
    else if((length == 11) && str_cmp(p_data, "AT+REBOOT", 9))   //����ģ��
    {
        sprintf(str_temp, "OK+REBOOT\r\n");
        usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp)); 
        
        osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , 1000 , 0 );
    }
    else if((length == 10) && str_cmp(p_data, "AT+RESET", 8))     //��λָ�����ģ����и�λ��
    {      
        set_default_sys_config();
        sprintf(str_temp, "OK+RESET\r\n");
        usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp)); 
        osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , 1000 , 0 );
    }
    else if((length == 10 ) && str_cmp(p_data, "AT+BAUD", 7))    //�޸Ĵ��ڲ�����ָ��
    {
        unsigned char ret = 0;
        unsigned int baud_value = 0;
 
        if(p_data[7] == '?')   //��ѯ��ǰ������
        {
            switch(sys_config.baudrate)
            {
                case BAUDRATE_9600:
                  sprintf(str_temp, "OK+GET:1\r\n");   
                  ret = 1; 
                break;
                  
                case BAUDRATE_19200:
                  sprintf(str_temp, "OK+GET:2\r\n");
                  ret = 1;
                break;
                
                case BAUDRATE_38400:
                  sprintf(str_temp, "OK+GET:3\r\n");
                  ret = 1;
                break;
                
                case BAUDRATE_115200:
                  sprintf(str_temp, "OK+GET:4\r\n");
                  ret = 1;
                break;
                                
                default:
                     
                break;
            }
            
            if(ret)usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp));                    
        }
        else   //���õ�ǰ������
        {
            baud_value = str_to_num(&p_data[7],1);            
            sys_config.baudrate = baud_value;
            
            if(baud_value == BAUDRATE_9600)sprintf(str_temp, "OK+SET:1\r\n");
            else if(baud_value == BAUDRATE_19200)sprintf(str_temp, "OK+SET:2\r\n");
            else if(baud_value == BAUDRATE_38400)sprintf(str_temp, "OK+SET:3\r\n");
            else if(baud_value == BAUDRATE_115200)sprintf(str_temp, "OK+SET:4\r\n");
            else sprintf(str_temp, "ERR_BAUD\r\n"); 
            
            if(baud_value)save_sys_config(&sys_config);
            usart1_send_package_data((unsigned char*)str_temp, strlen(str_temp));     
            osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , 1000 , 0 );
        }
    }
    else   //ָ���ʽ���󣬷��� ERROR
    {
        usart1_send_package_data("ERROR CMD\r\n",11); 
    }
    
}

unsigned char net_module_init(void)
{
    return 0;
}

void net_module_uninit(void)
{
    
}