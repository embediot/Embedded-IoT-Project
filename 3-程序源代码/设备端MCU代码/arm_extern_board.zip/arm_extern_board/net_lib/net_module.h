#ifndef _NET_MODULE_H_
#define _NET_MODULE_H_


extern void at_cmd_handle(unsigned char *p_data,unsigned char length);

extern unsigned char net_module_init(void);
extern void net_module_uninit(void);

#endif


