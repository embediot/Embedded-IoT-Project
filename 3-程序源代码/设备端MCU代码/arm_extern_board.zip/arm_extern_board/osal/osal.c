#include "stm32f0xx.h"
#include "stdlib.h"
#include "string.h"
#include "osal.h"
#include "osal_timers.h"
#include "osal_clock.h"



unsigned char active_task_id = TASK_NO_TASK;


#define TASKSCNT 10

//任务数组
static pTaskEventHandlerFn tasks_arr[TASKSCNT];

static unsigned char tasks_cnt = 0;  //当前任务列表的任务数

unsigned short tasks_events[TASKSCNT];

/***********************************************************
** 函 数 名: unsigned char osal_set_event(unsigned char task_id, unsigned short event_flag)
** 输  　入: task_id-任务id，event_flag-事件标志
** 输  　出: 无
** 功能描述: 事件设置函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
unsigned char osal_set_event(unsigned char task_id, unsigned short event_flag)
{
    if ( task_id < tasks_cnt )
    {
        __disable_irq();  
        
        tasks_events[task_id] |= event_flag;      //置事件标志位
        
        __enable_irq();   
        
        return 1;
    }
    else
    {
        return 0;
    }
}

/***********************************************************
** 函 数 名: unsigned char osal_clr_event(unsigned char task_id, unsigned short event_flag)
** 输  　入: task_id-任务id，event_flag-事件标志
** 输  　出: 无
** 功能描述: 事件清除函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
unsigned char osal_clear_event( unsigned char task_id, unsigned short event_flag )
{
    if ( task_id < tasks_cnt )
    {
        __disable_irq();  
        
        tasks_events[task_id] &= ~event_flag;      //清除事件标志
        
        __enable_irq();   
        
        return 1;
    }
    else
    {
        return 0;
    }
}

/***********************************************************
** 函 数 名: void run_system(void)
** 输  　入: 无
** 输  　出: 无
** 功能描述: 系统主循环函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
void run_system(void)
{
    unsigned char idx = 0;
    
    osal_time_update();    //更新系统时间
    
    do 
    {
        if (tasks_events[idx])   //查找当前就绪的任务
        {
              	
            break;
        }
    }while (++idx < tasks_cnt);
    
    if (idx < tasks_cnt)    //当前有任务就绪
    {
        unsigned short events;

        __disable_irq();  
        
        events = tasks_events[idx];     //在任务列表取出任务
        tasks_events[idx] = 0;  
        
        __enable_irq(); 

        //active_task_id = idx;
	events = (tasks_arr[idx])( idx, events );
	//active_task_id = TASK_NO_TASK;

	__disable_irq();  
	tasks_events[idx] |= events;      //保存未处理的事件
	__enable_irq();  
    }
}



/***********************************************************
** 函 数 名: unsigned char register_task_array(pTaskEventHandlerFn fun_task,unsigned char task_id)
** 输  　入: 无
** 输  　出: 无
** 功能描述: 注册任务列表函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
unsigned char register_task_array(pTaskEventHandlerFn fun_task,unsigned char task_id)
{
    unsigned char ret = 0;
    
    if(task_id < TASKSCNT)
    {
        tasks_arr[task_id] = fun_task;
        tasks_cnt++;
        ret = 1;
    }
    else
    {
        ret = 0;
    }
    
    
    
    return ret;
}












