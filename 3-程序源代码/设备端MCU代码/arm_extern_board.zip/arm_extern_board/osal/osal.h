#ifndef __OSAL_H_
#define __OSAL_H_

#define TASK_NO_TASK            0xFF


enum{
#ifdef USART1_ON   
    USART1_TASK_ID,
#endif
#ifdef USART2_ON   
    USART2_TASK_ID, 
#endif
    NRF24L01_TASK_ID,
    SI4432_TASK_ID,
    NET_TASK_ID,
    IWDG_TASK_ID,
    LED_TASK_ID,
    KEY_TASK_ID,
};

typedef unsigned short (*pTaskEventHandlerFn)( unsigned char task_id, unsigned short event );

/***********************************************************
** 函 数 名: unsigned char osal_set_event(unsigned char task_id, unsigned short event_flag)
** 输  　入: task_id-任务id，event_flag-事件标志
** 输  　出: 无
** 功能描述: 立即事件设置函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
extern unsigned char osal_set_event(unsigned char task_id, unsigned short event_flag);

/***********************************************************
** 函 数 名: unsigned char osal_clr_event(unsigned char task_id, unsigned short event_flag)
** 输  　入: task_id-任务id，event_flag-事件标志
** 输  　出: 无
** 功能描述: 立即事件清除函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
extern unsigned char osal_clear_event(unsigned char task_id, unsigned short event_flag);

/***********************************************************
** 函 数 名: void run_system(void)
** 输  　入: 无
** 输  　出: 无
** 功能描述: 系统主循环函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
extern void run_system(void);

/***********************************************************
** 函 数 名: unsigned char register_task_array(pTaskEventHandlerFn fun_task,unsigned char task_id)
** 输  　入: fun_task-任务的函数指针，task_id-任务id
** 输  　出: 无
** 功能描述: 注册任务列表函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
extern unsigned char register_task_array(pTaskEventHandlerFn fun_task,unsigned char task_id);

#endif
