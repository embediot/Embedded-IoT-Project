#ifndef __OSAL_H_
#define __OSAL_H_

#define TASK_NO_TASK            0xFF

#define TASKSCNT 10

enum{
#ifdef USART1_ON   
    USART1_TASK_ID,                    //串口1任务
#endif
#ifdef USART2_ON   
    USART2_TASK_ID,                    //串口2任务
#endif
    NRF24L01_TASK_ID,                  //nRF24L01任务
    SI4432_TASK_ID,                    //SI4432任务
    IWDG_TASK_ID,                      //看门狗任务
    LED_TASK_ID,                       //LED指示灯任务
};

typedef unsigned short (*pTaskEventHandlerFn)( unsigned char task_id, unsigned short event );

/***********************************************************
** 函 数 名: unsigned char osal_set_event(unsigned char task_id, unsigned short event_flag)
** 输  　入: task_id-任务id，event_flag-事件标志
** 输  　出: 无
** 功能描述: 立即事件设置函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
extern unsigned char osal_set_event(unsigned char task_id, unsigned short event_flag);

/***********************************************************
** 函 数 名: unsigned char osal_clr_event(unsigned char task_id, unsigned short event_flag)
** 输  　入: task_id-任务id，event_flag-事件标志
** 输  　出: 无
** 功能描述: 立即事件清除函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
extern unsigned char osal_clear_event(unsigned char task_id, unsigned short event_flag);

/***********************************************************
** 函 数 名: void run_system(void)
** 输  　入: 无
** 输  　出: 无
** 功能描述: 系统主循环函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
extern void run_system(void);

/***********************************************************
** 函 数 名: unsigned char register_task_array(pTaskEventHandlerFn fun_task,unsigned char task_id)
** 输  　入: fun_task-任务的函数指针，task_id-任务id
** 输  　出: 无
** 功能描述: 注册任务列表函数
** 全局变量: 无
** 调用模块: 无
** 作  　者: 
** 日  　期: 
***********************************************************/
extern unsigned char register_task_array(pTaskEventHandlerFn fun_task,unsigned char task_id);

#endif
