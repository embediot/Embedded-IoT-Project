#include "main.h"


const unsigned char lut_full_update[] =
{
    0x22, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x11, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x1E, 0x1E, 0x1E, 0x1E, 0x1E, 0x1E, 0x1E, 0x1E, 
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00
};

const unsigned char lut_partial_update[] =
{
    0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x0F, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};


//epd2in13Ƭѡ���ų�ʼ��
static void epd2in13_cs_gpio_init(void)
{
    GPIO_InitTypeDef  GPIO_InitStruct;
    
    RCC_AHBPeriphClockCmd(EPD_CS_PIN_SCK, ENABLE);
    
    GPIO_InitStruct.GPIO_Pin = EPD_CS_PIN;     
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_3;
    GPIO_Init(EPD_CS_PORT, &GPIO_InitStruct);
    
    EPD_CS_HIGH();
}



//epd2in13��ʼ����λ����
static void epd2in13_rst_gpio_init(void)
{
    GPIO_InitTypeDef  GPIO_InitStruct;
    
    RCC_AHBPeriphClockCmd(EPD_RST_PIN_SCK, ENABLE);
    
    GPIO_InitStruct.GPIO_Pin = EPD_RST_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_3;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL; 
    GPIO_Init(EPD_RST_PORT, &GPIO_InitStruct);
    
    EPD_RST_HIGH();
}


//epd2in13��ʼ������/��������
static void epd2in13_dc_gpio_init(void)
{
    GPIO_InitTypeDef  GPIO_InitStruct;
    
    RCC_AHBPeriphClockCmd(EPD_DC_PIN_SCK, ENABLE);
    
    GPIO_InitStruct.GPIO_Pin = EPD_DC_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_3;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL; 
    GPIO_Init(EPD_DC_PORT, &GPIO_InitStruct);
      
}


//epd2in13��ʼ��busy����
static void epd2in13_busy_gpio_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct; 

    RCC_AHBPeriphClockCmd(EPD_BUSY_PIN_SCK, ENABLE);
    
    GPIO_InitStruct.GPIO_Pin = EPD_BUSY_PIN;      
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_DOWN; 
    GPIO_Init(EPD_BUSY_PORT, &GPIO_InitStruct);    
}


//epd2in13��������
static void epd2in13_send_command(unsigned char command)
{
    EPD_DC_LOW();
    
    EPD_CS_LOW();
    EPD2IN13_SPI_READ_WRITE_BYTE(command);
    EPD_CS_HIGH();
}


//epd2in13��������
static void epd2in13_send_data(unsigned char data)
{
    EPD_DC_HIGH();
    
    EPD_CS_LOW();
    EPD2IN13_SPI_READ_WRITE_BYTE(data);
    EPD_CS_HIGH();
}

//�ڳ�ʼ����ʱ������look up table
static void epd2in13_set_lookup_table(const unsigned char* lut) 
{
    epd2in13_send_command(WRITE_LUT_REGISTER);
  
    /* the length of look-up table is 30 bytes */
    for (int i = 0; i < 30; i++) 
    {
        epd2in13_send_data(lut[i]);
    } 
}

//�ȴ�ģ�����
static void epd2in13_wait_until_idle(void) 
{
    while(EPD_BUSY_LEVEL() == Bit_SET)   //0: busy, 1: idle
    {      
        delay_ms(100);
    }      
}


//������ʾ�ڴ������
static void epd2in13_set_memory_area(int x_start, int y_start, int x_end, int y_end) 
{
    epd2in13_send_command(SET_RAM_X_ADDRESS_START_END_POSITION);
    /* x point must be the multiple of 8 or the last 3 bits will be ignored */
    epd2in13_send_data((x_start >> 3) & 0xFF);
    epd2in13_send_data((x_end >> 3) & 0xFF);
    epd2in13_send_command(SET_RAM_Y_ADDRESS_START_END_POSITION);
    epd2in13_send_data(y_start & 0xFF);
    epd2in13_send_data((y_start >> 8) & 0xFF);
    epd2in13_send_data(y_end & 0xFF);
    epd2in13_send_data((y_end >> 8) & 0xFF);
}


//������ʾ�ڴ��x��y����
static void epd2in13_set_memory_pointer(int x, int y) 
{
    epd2in13_send_command(SET_RAM_X_ADDRESS_COUNTER);
    /* x point must be the multiple of 8 or the last 3 bits will be ignored */
    epd2in13_send_data((x >> 3) & 0xFF);
    epd2in13_send_command(SET_RAM_Y_ADDRESS_COUNTER);
    epd2in13_send_data(y & 0xFF);
    epd2in13_send_data((y >> 8) & 0xFF);
    epd2in13_wait_until_idle();
}











/***** �ⲿ���ú��� *****/
void epd2in13_sleep(void) 
{
    epd2in13_send_command(DEEP_SLEEP_MODE);
    epd2in13_wait_until_idle();
}

//epd2in13��λ����
void epd2in13_reset(void)
{
    EPD_RST_LOW();
    delay_ms(200);
    EPD_RST_HIGH();
    delay_ms(200);
}


//epd2in13ģ���ʼ��
void epd2in13_init(const unsigned char *types_of_lut)
{
    spi1_init();
      
    delay_ms(200);
     
    epd2in13_cs_gpio_init();      //��ʼ��Ƭѡ����
    epd2in13_rst_gpio_init();     //��ʼ����λ����
    epd2in13_dc_gpio_init();      //��ʼ������/��������
    epd2in13_busy_gpio_init();    //��ʼ��busy����
     
    /* EPD hardware init start */
    epd2in13_reset();             //��λepd2in13ģ��
    epd2in13_send_command(DRIVER_OUTPUT_CONTROL);
    epd2in13_send_data((EPD_HEIGHT - 1) & 0xFF);
    epd2in13_send_data(((EPD_HEIGHT - 1) >> 8) & 0xFF);
    epd2in13_send_data(0x00);                     // GD = 0; SM = 0; TB = 0;
    epd2in13_send_command(BOOSTER_SOFT_START_CONTROL);
    epd2in13_send_data(0xD7);
    epd2in13_send_data(0xD6);
    epd2in13_send_data(0x9D);
    epd2in13_send_command(WRITE_VCOM_REGISTER);
    epd2in13_send_data(0xA8);                     // VCOM 7C
    epd2in13_send_command(SET_DUMMY_LINE_PERIOD);
    epd2in13_send_data(0x1A);                     // 4 dummy lines per gate
    epd2in13_send_command(SET_GATE_TIME);
    epd2in13_send_data(0x08);                     // 2us per line
    epd2in13_send_command(DATA_ENTRY_MODE_SETTING);
    epd2in13_send_data(0x03);                     // X increment; Y increment
    epd2in13_set_lookup_table(types_of_lut);
    /* EPD hardware init end */
    
}


//����֡����
void epd2in13_set_frame_memory(const unsigned char* image_buffer,int x,int y,int image_width,int image_height) 
{
    int x_end;
    int y_end;

    if(image_buffer == NULL || x < 0 || image_width < 0 || y < 0 || image_height < 0)return;

    /* x point must be the multiple of 8 or the last 3 bits will be ignored */
    x &= 0xF8;image_width &= 0xF8;
    
    if (x + image_width >= EPD_WIDTH) 
        x_end = EPD_WIDTH - 1;
    else 
        x_end = x + image_width - 1;
    
    if (y + image_height >= EPD_HEIGHT) 
        y_end = EPD_HEIGHT - 1;
    else 
        y_end = y + image_height - 1;
    
    epd2in13_set_memory_area(x, y, x_end, y_end);
    
    /* set the frame memory line by line */
    for (int j = y; j <= y_end; j++) 
    {
        epd2in13_set_memory_pointer(x, j);
        epd2in13_send_command(WRITE_RAM);
        
        for (int i = x/8; i <= x_end/8; i++) 
        {
            epd2in13_send_data(image_buffer[(i - x / 8) + (j - y) * (image_width / 8)]);
        }
    }
}

//���֡����
void epd2in13_clear_frame_memory(unsigned char color) 
{ 
    epd2in13_set_memory_area(0, 0, EPD_WIDTH - 1, EPD_HEIGHT - 1);
    
    for (int j = 0; j < EPD_HEIGHT; j++)   /* set the frame memory line by line */
    {
        epd2in13_set_memory_pointer(0, j);
        epd2in13_send_command(WRITE_RAM);
        
        for (int i = 0; i < EPD_WIDTH/8; i++) 
        {
            epd2in13_send_data(color);
        }
    }
}


//��ʾ֡����
void epd2in13_display_frame(void) 
{
    epd2in13_send_command(DISPLAY_UPDATE_CONTROL_2);
    epd2in13_send_data(0xC4);
    epd2in13_send_command(MASTER_ACTIVATION);
    epd2in13_send_command(TERMINATE_FRAME_READ_WRITE);
    epd2in13_wait_until_idle();
}

