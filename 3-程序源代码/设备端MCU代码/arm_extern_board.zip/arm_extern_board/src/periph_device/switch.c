#include "main.h"



//����gpio��ʼ��
void switch_gpio_init(void)
{    
    GPIO_InitTypeDef GPIO_InitStruct; 

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    
    //���򿪹أ��������ֲ�ͬ����������
    GPIO_InitStruct.GPIO_Pin = AREA_SWITCH_PIN0 | AREA_SWITCH_PIN1;      
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_DOWN; 
    GPIO_Init(SWITCH_PORTB, &GPIO_InitStruct);
        
    //��ַ���أ�ͬһ���������ڵĲ�ͬ��ַ
    GPIO_InitStruct.GPIO_Pin = ADDR_SWITCH_PIN0;      
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_DOWN; 
    GPIO_Init(SWITCH_PORTA, &GPIO_InitStruct);
    
    GPIO_InitStruct.GPIO_Pin = ADDR_SWITCH_PIN1 | ADDR_SWITCH_PIN2 | ADDR_SWITCH_PIN3 | ADDR_SWITCH_PIN4
                              | ADDR_SWITCH_PIN5 | ADDR_SWITCH_PIN6 | ADDR_SWITCH_PIN7;      
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_DOWN; 
    GPIO_Init(SWITCH_PORTB, &GPIO_InitStruct);        
}

//��ȡ����ֵ
//switch_value: bit0-7:addr_value   bit8-9:area_value
unsigned short get_switch_value(void)
{
    unsigned short switch_value = 0;
    unsigned char temp_value = 0;
        
    //area value       
    temp_value = (unsigned char)(GPIO_ReadInputData(SWITCH_PORTB) & 0x0003);
    switch_value |= (temp_value << 8);
    
    //addr value
    temp_value = GPIO_ReadInputDataBit(SWITCH_PORTA, ADDR_SWITCH_PIN0);
    switch_value |= (temp_value << 0);
    
    temp_value = (unsigned char)((GPIO_ReadInputData(SWITCH_PORTB) & 0x03F8) >> 3);
    switch_value |= (temp_value << 1);
    
    return switch_value;
}



















