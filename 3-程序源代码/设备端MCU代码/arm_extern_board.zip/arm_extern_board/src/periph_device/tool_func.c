#include "main.h"

//���ַ��ݹ��㷨
int recurbinary(int *a, int key, int low, int high)
{
    int mid;
    if(low > high)return -1;
    
    mid = (low + high)/2;
    
    if(a[mid] == key)
    {
        return mid;
    }
    else if(a[mid] > key)
    {
        return recurbinary(a,key,low,mid -1);
    }
    else
    {
        return recurbinary(a,key,mid + 1,high);
    }
}
 
//���ַ��ǵݹ��㷨
int binary(const float a[][2], float key, int n )
{
    int left = 0;
    int right = 0;
    int mid = 0;
    float temp_value;
    
    right = n - 1;
    mid = (left + right) / 2;
    temp_value = a[mid][0];
    
    while((left < right) && (temp_value != key))
    {
        if( a[mid][0] < key ) 
        {
            left = mid + 1;
        } 
        else if( a[mid][0] > key ) 
        {
            right = mid;
        }
        mid = ( left + right ) / 2;
        temp_value = a[mid][0];
    }
    if( a[mid][0] == key )
      return mid;
    
    return -1;
}

//����ת�ַ���
char* my_itoa(int value,char *str,int radix)  
{  
    int sign = 0;  
    //char *s = str;  
    char ps[32];  
    memset(ps,0,32);  
    int i=0;  
    
    if(value < 0)  
    {  
        sign = -1;  
        value = -value;  
    }  
    do  
    {  
        if(value % radix>9)  
            ps[i] = value % radix +'0'+7;  
        else   
            ps[i] = value % radix +'0';  
        i++;  
    }while((value /= radix)>0);  
    
    if(sign < 0)ps[i] = '-';  
    else i--;  
    
    for(int j=i;j>=0;j--)  
    {  
        str[i-j] = ps[j];  
    }  
    
    return str;  
}  

//������ת�ַ���
char *my_ftoa(double number,int ndigit,char *buf)  
{  
    long int_part;  
    double float_part;  
    char str_int[32];  
    char str_float[32];  
    
    memset(str_int,0,32);  
    memset(str_float,0,32);  
    int_part = (long)number;  
    float_part = number - int_part;  
   
    my_itoa(int_part,str_int,10);   // �������ִ���  
    
    if(ndigit > 0)  // С�����ִ���  
    {  
        float_part = fabs(pow(10,ndigit)*float_part);  
        my_itoa((long)float_part,str_float,10);  
    } 
    
    int i = strlen(str_int);  
    str_int[i] = '.';  
    strcat(str_int,str_float);  
    strcpy(buf,str_int);  
    
    return buf;  
}

// �ַ����Ա�
unsigned char str_cmp(unsigned char *p1,unsigned char *p2,unsigned char len)
{
  unsigned char i=0;
  
  while(i < len){
    if(p1[i] != p2[i])return 0;      
    i++;
  }
  return 1;
}

// �ַ���ת����
unsigned int str_to_num(unsigned char* p_str, unsigned char len)
{
    unsigned char i = 0;
    int ret_value = 0;
 
    for(; i < len && p_str[i] != '\0'; ++i)
        ret_value = ret_value * 10 + (p_str[i] - '0');    
 
    return ret_value;
}


