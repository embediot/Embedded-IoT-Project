#include "main.h"


#ifndef SPI_DMA         //���û��ʹ��SPI_DMA����������´���

#ifdef SPI1_ON  
//spi1���ų�ʼ��
void spi1_init(void)
{
    GPIO_InitTypeDef  GPIO_InitStruct;
    SPI_InitTypeDef   SPI_InitStruct;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(SPI1_RCC, ENABLE); 

    GPIO_InitStruct.GPIO_Pin = SPI1_SCK_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_3;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP; 
    GPIO_Init(SPI1_SCK_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.GPIO_Pin = SPI1_MISO_PIN;
    GPIO_Init(SPI1_MISO_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.GPIO_Pin =SPI1_MOSI_PIN;
    GPIO_Init(SPI1_MOSI_PORT, &GPIO_InitStruct);

    GPIO_PinAFConfig(SPI1_SCK_PORT, SPI1_SCK_SOURCE, SPI1_SCK_AF);
    GPIO_PinAFConfig(SPI1_MISO_PORT, SPI1_MISO_SOURCE, SPI1_MISO_AF); 
    GPIO_PinAFConfig(SPI1_MOSI_PORT, SPI1_MOSI_SOURCE, SPI1_MOSI_AF);
         
    SPI_InitStruct.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    //SPI_InitStruct.SPI_Direction = SPI_Direction_1Line_Tx;
    SPI_InitStruct.SPI_Mode = SPI_Mode_Master;
    SPI_InitStruct.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStruct.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStruct.SPI_CPHA = SPI_CPHA_1Edge;//SPI_CPHA_1Edge;
    SPI_InitStruct.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStruct.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;
    SPI_InitStruct.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStruct.SPI_CRCPolynomial = 10;
    SPI_Init(SPI1, &SPI_InitStruct);
    SPI_RxFIFOThresholdConfig(SPI1, SPI_RxFIFOThreshold_QF);
    
    SPI_Cmd(SPI1, ENABLE);      
}

//ͨ�� spi ���͵��ֽ�����
unsigned char spi1_send_byte(unsigned char byte)
{
    unsigned char ret = 0;
         
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
    //while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) != RESET);
    
    SPI_SendData8(SPI1, byte);

    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);
    //while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) != RESET);
    
    ret = SPI_ReceiveData8(SPI1);
      
    return ret;
}

#endif

#ifdef SPI2_ON
//spi2���ų�ʼ��
void spi2_init(void)
{
    GPIO_InitTypeDef  GPIO_InitStruct;
    SPI_InitTypeDef   SPI_InitStruct;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(SPI2_RCC, ENABLE); 

    GPIO_InitStruct.GPIO_Pin = SPI2_SCK_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_3;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP; 
    GPIO_Init(SPI2_SCK_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.GPIO_Pin = SPI2_MISO_PIN;
    GPIO_Init(SPI2_MISO_PORT, &GPIO_InitStruct);

    GPIO_InitStruct.GPIO_Pin =SPI2_MOSI_PIN;
    GPIO_Init(SPI2_MOSI_PORT, &GPIO_InitStruct);

    GPIO_PinAFConfig(SPI2_SCK_PORT, SPI2_SCK_SOURCE, SPI2_SCK_AF);
    GPIO_PinAFConfig(SPI2_MISO_PORT, SPI2_MISO_SOURCE, SPI2_MISO_AF); 
    GPIO_PinAFConfig(SPI2_MOSI_PORT, SPI2_MOSI_SOURCE, SPI2_MOSI_AF);
    
    SPI_Cmd(SPI2, DISABLE); 
    
    SPI_InitStruct.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    //SPI_InitStruct.SPI_Direction = SPI_Direction_1Line_Tx;
    SPI_InitStruct.SPI_Mode = SPI_Mode_Master;
    SPI_InitStruct.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStruct.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStruct.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStruct.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStruct.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_64;
    SPI_InitStruct.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStruct.SPI_CRCPolynomial = 7;
    SPI_Init(SPI2, &SPI_InitStruct);
    
    SPI_RxFIFOThresholdConfig(SPI2, SPI_RxFIFOThreshold_QF);
    
    SPI_Cmd(SPI2, ENABLE);      
}

//ͨ�� spi ���͵��ֽ�����
unsigned char spi2_send_byte(unsigned char byte)
{
    unsigned char ret = 0;
    
    while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
    //while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) != RESET);
    
    SPI_SendData8(SPI2, byte);

    while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET);
    //while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) != RESET);
    
    ret = SPI_ReceiveData8(SPI2);
    
    
    return ret;
  
  
}

#endif

#endif

