#ifndef __DHT11_H_
#define __DHT11_H_


//dht11�������Ŷ���
#define DHT11_DQ_PORT             GPIOB
#define DHT11_DQ_PIN              GPIO_Pin_7
#define DHT11_DQ_PIN_SCK          RCC_AHBPeriph_GPIOB

//����DHT11_DQOUT��ƽ״̬
#define SET_DHT11_DQ_HIGH()       GPIO_SetBits(DHT11_DQ_PORT, DHT11_DQ_PIN)
#define SET_DHT11_DQ_LOW()        GPIO_ResetBits(DHT11_DQ_PORT, DHT11_DQ_PIN)

//IO��������
//#define SET_DHT11_IO_IN()         {DHT11_DQ_PORT->MODER &= ~(3<<(7*2));DHT11_DQ_PORT->MODER |= (0<<(7*2));}	        //PB7����ģʽ
//#define SET_DHT11_IO_OUT()        {DHT11_DQ_PORT->MODER &= ~(3<<(7*2));DHT11_DQ_PORT->MODER |= (1<<(7*2));}      	//PB7���ģʽ 

#define SET_DHT11_IO_IN()         dht11_gpio_input()//{DHT11_DQ_PORT->MODER &= ~(3<<(7*2));DHT11_DQ_PORT->MODER |= (0<<(7*2));}	        //PB7����ģʽ
#define SET_DHT11_IO_OUT()        dht11_gpio_output()//{DHT11_DQ_PORT->MODER &= ~(3<<(7*2));DHT11_DQ_PORT->MODER |= (1<<(7*2));}      	//PB7���ģʽ 


//��ȡDHT11_DQ��ƽ״̬
#define GET_DHT11_IO_STATE()      GPIO_ReadInputDataBit(DHT11_DQ_PORT, DHT11_DQ_PIN)

extern unsigned char dht11_init(void);  //��ʼ��DHT11
extern unsigned char dht11_read_data(unsigned char *temp,unsigned char *humi);   //��ȡ��ʪ��



#endif


