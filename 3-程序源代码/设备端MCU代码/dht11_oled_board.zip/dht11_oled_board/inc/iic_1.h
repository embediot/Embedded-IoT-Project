#ifndef __IIC_1_H_
#define __IIC_1_H_


//IIC���ź궨��
#define IIC1_SCL_PORT              GPIOB
#define IIC1_SCL_PIN               GPIO_Pin_8
#define IIC1_SCL_PIN_SCK           RCC_AHBPeriph_GPIOB


#define IIC1_SDA_PORT              GPIOB
#define IIC1_SDA_PIN               GPIO_Pin_9
#define IIC1_SDA_PIN_SCK           RCC_AHBPeriph_GPIOB

//����IIC_SDA����
//#define SET_IIC1_SDA_IN()        {GPIOF->MODER &= 0XFFFF0FFF;GPIOF->MODER &= ~(1<<14);}	 
//#define SET_IIC1_SDA_OUT()       {GPIOF->MODER &= 0XFFFF0FFF;GPIOF->MODER |= (1<<14);}       

#define SET_IIC1_SDA_IN()        set_iic1_sda_in()	      
#define SET_IIC1_SDA_OUT()       set_iic1_sda_out()       

//����IIC_SDA��ƽ״̬
#define SET_IIC1_SDA_HIGH()      GPIO_SetBits(IIC1_SDA_PORT, IIC1_SDA_PIN)
#define SET_IIC1_SDA_LOW()       GPIO_ResetBits(IIC1_SDA_PORT, IIC1_SDA_PIN)

//����IIC_SCL��ƽ״̬
#define SET_IIC1_SCL_HIGH()      GPIO_SetBits(IIC1_SCL_PORT, IIC1_SCL_PIN)
#define SET_IIC1_SCL_LOW()       GPIO_ResetBits(IIC1_SCL_PORT, IIC1_SCL_PIN)

//��ȡIIC_SDA��ƽ״̬
#define GET_IIC1_SDA_STATE()     GPIO_ReadInputDataBit(IIC1_SDA_PORT, IIC1_SDA_PIN)





extern void iic1_gpio_init(void);
extern void iic1_start(void);
extern void iic1_stop(void);
extern unsigned char iic1_wait_ack(void);
extern void iic1_ack(void);
extern void iic1_no_ack(void);
extern void iic1_send_byte(unsigned char byte);
extern unsigned char iic1_read_byte(void);




#endif


