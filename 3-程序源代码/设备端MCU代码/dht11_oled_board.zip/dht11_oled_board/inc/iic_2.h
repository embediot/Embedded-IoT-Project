#ifndef __IIC_2_H_
#define __IIC_2_H_


//IIC���ź궨��
#define IIC2_SCL_PORT              GPIOF
#define IIC2_SCL_PIN               GPIO_Pin_6
#define IIC2_SCL_PIN_SCK           RCC_AHBPeriph_GPIOF


#define IIC2_SDA_PORT              GPIOF
#define IIC2_SDA_PIN               GPIO_Pin_7
#define IIC2_SDA_PIN_SCK           RCC_AHBPeriph_GPIOF

//����IIC_SDA����
//#define SET_IIC_SDA_IN()        {GPIOF->MODER &= 0XFFFF0FFF;GPIOF->MODER &= ~(1<<14);}	      //PF7 ����
//#define SET_IIC_SDA_OUT()       {GPIOF->MODER &= 0XFFFF0FFF;GPIOF->MODER |= (1<<14);}        //PF7 ���

#define SET_IIC2_SDA_IN()        set_iic2_sda_in()	      //PF7 ����
#define SET_IIC2_SDA_OUT()       set_iic2_sda_out()       //PF7 ���

//����IIC_SDA��ƽ״̬
#define SET_IIC2_SDA_HIGH()      GPIO_SetBits(IIC2_SDA_PORT, IIC2_SDA_PIN)
#define SET_IIC2_SDA_LOW()       GPIO_ResetBits(IIC2_SDA_PORT, IIC2_SDA_PIN)

//����IIC_SCL��ƽ״̬
#define SET_IIC2_SCL_HIGH()      GPIO_SetBits(IIC2_SCL_PORT, IIC2_SCL_PIN)
#define SET_IIC2_SCL_LOW()       GPIO_ResetBits(IIC2_SCL_PORT, IIC2_SCL_PIN)

//��ȡIIC_SDA��ƽ״̬
#define GET_IIC2_SDA_STATE()     GPIO_ReadInputDataBit(IIC2_SDA_PORT, IIC2_SDA_PIN)





extern void iic2_gpio_init(void);
extern void iic2_start(void);
extern void iic2_stop(void);
extern unsigned char iic2_wait_ack(void);
extern void iic2_ack(void);
extern void iic2_no_ack(void);
extern void iic2_send_byte(unsigned char byte);
extern unsigned char iic2_read_byte(void);




#endif


