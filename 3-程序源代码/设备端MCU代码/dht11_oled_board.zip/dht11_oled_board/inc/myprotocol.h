#ifndef __PROTOCOL_H_
#define __PROTOCOL_H_

#define     FRAME_HEAD                     0xF5
#define     CMD_SLAVE_NET_IN               0xB0   //�ӻ�����ָ��
#define     CMD_MASTER_CTRL_SLAVE          0xB1   //�������ƴӻ�ָ��



#define RET_SUCCESS           0x00   //�ɹ�
#define RET_FAIL              0x01   //ʧ��
#define RET_CRC_ERROR         0x02   //CRC����
#define RET_PWD_ERROR         0x03   //�������
#define RET_ADDR_ERROR        0x04   //��ַ����
#define RET_TIMEOUT           0x05   //��ʱ
//End

#define UNVARNISHED_TRANSMISSION      0x10        //͸��
#define LOCAL_PROCESSING              0x1F        //���ش���


//ͨ�Ÿ�ʽ�ṹ��
#define MAX_DATA_LEN        256     //������ݳ���
#define FRAME_HEAD_LEN      5
typedef union UN_COMMUNICATE_BUFF
{
     uint8 databuff[MAX_DATA_LEN];
     struct
     {
          uint8 head;
          uint8 crc_hi;
          uint8 crc_lo;
          uint8 len;
          uint8 cmd;
          uint8 data[MAX_DATA_LEN-FRAME_HEAD_LEN];
     }Frame;    
}TYP_UN_COMMUNICATE_BUFF;


extern unsigned char check_crc(void *p_data);
extern unsigned char protocol_data_package(unsigned char cmd,unsigned char len,unsigned char *p_in,TYP_UN_COMMUNICATE_BUFF *p_data);
extern void clear_buff(void *ptr,uint8 len);


#endif

