#ifndef __OLED_TASK_H_
#define __OLED_TASK_H_

#define OLED_TASK_START_EVENT            0x0001     //OLED���������¼�
#define OLED_DHT11_EVENT                 0x0002   

extern void oled_display_title(unsigned char *p_data);
extern void oled_display_wifi_status(unsigned char wifi_state);

extern void oled_task_init(void);

#endif

