#include "main.h"


/***********************************************************
** function    : static void dht11_gpio_output(void)
** input       : ��
** output      : ��
** description : ����DHT11 IO�����
** author      :
** date        :
***********************************************************/
static void dht11_gpio_output(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(DHT11_DQ_PIN_SCK, ENABLE);//ʹ��GPIOBʱ��

    GPIO_InitStructure.GPIO_Pin = DHT11_DQ_PIN ;   //��ʼ��PB7
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;   //��ͨ���ģʽ
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //�������
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_2;//10MHz
    GPIO_Init(DHT11_DQ_PORT, &GPIO_InitStructure);   //��ʼ��
}

/***********************************************************
** function    : static void dht11_gpio_input(void)
** input       : ��
** output      : ��
** description : ����DHT11 IO������
** author      :
** date        :
***********************************************************/
static void dht11_gpio_input(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(DHT11_DQ_PIN_SCK, ENABLE);     //ʹ��GPIOBʱ��

    GPIO_InitStructure.GPIO_Pin = DHT11_DQ_PIN ;         //��ʼ��PB7
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;         //��ͨ����ģʽ
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;         //��������ģʽ
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Level_2;    //10MHz
    GPIO_Init(DHT11_DQ_PORT, &GPIO_InitStructure);       //��ʼ��
}

/***********************************************************
** function    : static void dht11_rst(void)
** input       : ��
** output      : ��
** description : ��λDHT11
** author      :
** date        :
***********************************************************/
static void dht11_rst(void)
{
    SET_DHT11_IO_OUT();      //�������ģʽ
    SET_DHT11_DQ_LOW();      //����DQ
    delay_ms(20);            //��������18ms
    SET_DHT11_DQ_HIGH();     //����DQ
    delay_us(30);            //��������20~40us
    SET_DHT11_IO_IN();   //��������ģʽ
}

/***********************************************************
** function    : static unsigned char dht11_check(void)
** input       : ��
** output      : 0-�ɹ�  1-ʧ��
** description : ���DHT11�Ĵ��ڣ��ȴ�DHT11�Ļ�Ӧ
** author      :
** date        :
***********************************************************/
static unsigned char dht11_check(void)
{
    return GET_DHT11_IO_STATE();
}

/***********************************************************
** function    : static unsigned char dht11_read_bit(void)
** input       : ��
** output      : 0 �� 1
** description : ��DHT11��ȡһ��λ
** author      :
** date        :
***********************************************************/
static unsigned char dht11_read_bit(void)
{
    unsigned char retry = 0;

    while (GET_DHT11_IO_STATE() == RESET)
    {
        retry++;
        delay_us(1);
        if(retry > 200)break;
    }
    
    delay_us(40);
    
    retry = 0;
    
    if (GET_DHT11_IO_STATE() == SET)
    {
        while (GET_DHT11_IO_STATE() == SET);
        return 1;
    }
    else
    {
        return 0;
    }
}

/***********************************************************
** function    : static unsigned char dht11_read_byte(void)
** input       : ��
** output      : ����������
** description : ��DHT11��ȡһ���ֽ�
** author      :
** date        :
***********************************************************/
static unsigned char dht11_read_byte(void)
{
    unsigned char i;
    unsigned char data = 0;

    for(i = 0;i < 8;i++)
    {
        data <<= 1;
        data |= dht11_read_bit();
    }
    return data;
}


/***********************************************************
** function    : unsigned char dht11_init(void)
** input       : ��
** output      : 0-�ɹ�  1-ʧ��
** description : ��ʼ��DHT11��IO��DQͬʱ���GHT11�Ĵ���
** author      :
** date        :
***********************************************************/
unsigned char dht11_init(void)
{
    dht11_gpio_output();

    dht11_rst();

    return dht11_check();
}

/***********************************************************
** function    : unsigned char dht11_read_data(unsigned char *temp,unsigned char *humi)
** input       : temp-�¶�ֵ����Χ��0~50�㣩 humi-ʪ��ֵ����Χ��20%~90%��
** output      : 0-������1-ʧ��
** description : ��DHT11��ȡһ������
** author      :
** date        :
***********************************************************/
unsigned char dht11_read_data(unsigned char *temp,unsigned char *humi)
{
    unsigned char i = 0;
    static unsigned char buffer[5];
    
    dht11_rst();
    if (dht11_check() == RESET)
    {
        //��⵽DHT11��Ӧ
        while (dht11_check() == RESET);
        while (dht11_check() == SET);
        for (i = 0; i < 5; i++)
        {
            buffer[i] = dht11_read_byte();
        }
        
        while (dht11_check() == RESET);
        dht11_gpio_output();
        SET_DHT11_DQ_HIGH();
        
        u8 checksum = buffer[0] + buffer[1] + buffer[2] + buffer[3];
        if (checksum != buffer[4])
        {
            // checksum error
            return 1;
        }
        else
        {
            *humi = buffer[0];
            *temp = buffer[2];
        }
    }
    
    return 0;

}

