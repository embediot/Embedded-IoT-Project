#include "main.h"


static void set_iic2_sda_in(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    	
    GPIO_InitStruct.GPIO_Pin = IIC2_SDA_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP; 
    GPIO_Init(IIC2_SDA_PORT, &GPIO_InitStruct);
}

static void set_iic2_sda_out(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    
    GPIO_InitStruct.GPIO_Pin = IIC2_SDA_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL; 
    GPIO_Init(IIC2_SDA_PORT, &GPIO_InitStruct);
}

/***********************************************************
** function    : void iic_gpio_init(void)
** input       : 
** output      : 
** description : ��ʼ��iic gpio�˿�
** author      :
** date        :
***********************************************************/
void iic2_gpio_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    
    RCC_AHBPeriphClockCmd(IIC2_SCL_PIN_SCK, ENABLE );
    GPIO_InitStruct.GPIO_Pin = IIC2_SCL_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL; 
    GPIO_Init(IIC2_SCL_PORT, &GPIO_InitStruct);
    
    RCC_AHBPeriphClockCmd(IIC2_SDA_PIN_SCK, ENABLE );	
    GPIO_InitStruct.GPIO_Pin = IIC2_SDA_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL; 
    GPIO_Init(IIC2_SDA_PORT, &GPIO_InitStruct);
    
    GPIO_SetBits(IIC2_SCL_PORT,IIC2_SCL_PIN);  
    GPIO_SetBits(IIC2_SDA_PORT,IIC2_SDA_PIN);  
}

/***********************************************************
** function    : void iic_start(void)
** input       : 
** output      : 
** description : iic��ʼ�ź�
** author      :
** date        :
***********************************************************/
void iic2_start(void)
{
    SET_IIC2_SDA_OUT();     //sda�����
    SET_IIC2_SDA_HIGH();	  	  
    SET_IIC2_SCL_HIGH();
    delay_us(5);
    SET_IIC2_SDA_LOW();       //START:when CLK is high,DATA change form high to low 
    delay_us(5);
    SET_IIC2_SCL_LOW();       //ǯסI2C���ߣ�׼�����ͻ�������� 
}

/***********************************************************
** function    : void iic_stop(void)
** input       : 
** output      : 
** description : iicֹͣ�ź�
** author      :
** date        :
***********************************************************/
void iic2_stop(void)
{
    SET_IIC2_SDA_OUT();     //sda�����
    SET_IIC2_SDA_LOW();     //STOP:when CLK is high DATA change form low to high
    SET_IIC2_SCL_LOW();
    delay_us(5);
    SET_IIC2_SCL_HIGH(); 
    delay_us(5);
    SET_IIC2_SDA_HIGH();	   //����I2C���߽����ź�
    delay_us(5);				
}

/***********************************************************
** function    : unsigned char iic_wait_ack(void)
** input       : 
** output      : 1-����Ӧ��ʧ�ܣ�0-����Ӧ��ɹ�
** description : iic�ȴ�Ӧ��
** author      :
** date        :
***********************************************************/
unsigned char iic2_wait_ack(void)
{
    unsigned char err_times = 0;

    SET_IIC2_SDA_IN();             //SDA����Ϊ����  
    SET_IIC2_SDA_HIGH();
    delay_us(5);	   
    SET_IIC2_SCL_HIGH();
    delay_us(5);	 

    while(GET_IIC2_SDA_STATE())
    {
        err_times++;
        if(err_times>250)
        {
            iic2_stop();
            return 1;
        }
    }
    SET_IIC2_SCL_LOW();           //ʱ�����0 	   
    delay_us(5);

    return 0;  
}

/***********************************************************
** function    : void iic_ack(void)
** input       : 
** output      : 
** description : iic����Ӧ��
** author      :
** date        :
***********************************************************/
void iic2_ack(void)
{
    //SET_IIC_SCL_LOW(); 
    SET_IIC2_SDA_OUT();
    SET_IIC2_SDA_LOW();
    delay_us(5);
    SET_IIC2_SCL_HIGH();
    delay_us(5);
    SET_IIC2_SCL_LOW();  
}

/***********************************************************
** function    : void iic_no_ack(void)
** input       : 
** output      : 
** description : iic������Ӧ��
** author      :
** date        :
***********************************************************/
void iic2_no_ack(void)
{
    //SET_IIC_SCL_LOW();
    SET_IIC2_SDA_OUT();
    SET_IIC2_SDA_HIGH();
    delay_us(5);
    SET_IIC2_SCL_HIGH();
    delay_us(5);
    SET_IIC2_SCL_LOW();  
}

/***********************************************************
** function    : void iic_send_byte(unsigned char byte)
** input       : byte-Ҫ���͵��ֽ�
** output      : 
** description : iic����һ���ֽ�
** author      :
** date        :
***********************************************************/
void iic2_send_byte(unsigned char byte)
{
    unsigned char i;

    SET_IIC2_SDA_OUT(); 

    SET_IIC2_SCL_LOW();               //����ʱ�ӿ�ʼ���ݴ���

    for(i=0;i<8;i++)
    {              
        if((byte&0x80)>>7)SET_IIC2_SDA_HIGH();
        else SET_IIC2_SDA_LOW();

        byte <<= 1; 	  
        //delay_us(2);  
        SET_IIC2_SCL_HIGH();
        delay_us(5); 
        SET_IIC2_SCL_LOW();  
        //delay_us(2);
    }	 
}

/***********************************************************
** function    : void iic_send_byte(unsigned char byte)
** input       : ack_flag-1������ack��0-����nack
** output      : ���ض�ȡ���ֽ�
** description : iic��ȡһ���ֽ�
** author      :
** date        :
***********************************************************/
unsigned char iic2_read_byte(void)
{
    unsigned char i,receive = 0;

    SET_IIC2_SDA_IN();       //SDA����Ϊ����

    for(i=0;i<8;i++)
    {         
        SET_IIC2_SCL_HIGH();
        receive <<= 1;
        if(GET_IIC2_SDA_STATE())receive++;   
        SET_IIC2_SCL_LOW(); 
        delay_us(5); 
    }

//    if (!ack_flag)iic_no_ack();          //����nACK
//    else iic_ack();                      //����ACK   

    return receive;
}



