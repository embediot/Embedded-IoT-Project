#ifndef __KEY_H_
#define __KEY_H_



/** RESET KEY Ӳ���ӿڶ��� */
#define RESET_KEY_PIN               GPIO_Pin_6
#define RESET_KEY_PORT              GPIOF
#define RESET_KEY_PIN_SCK           RCC_AHBPeriph_GPIOF
#define RESET_KEY_EXTI_PORT_SRC     EXTI_PortSourceGPIOF
#define RESET_KEY_EXTI_PIN_SRC      EXTI_PinSource6
#define RESET_KEY_EXTI_LINE         EXTI_Line6
#define RESET_KEY_IRQ_CHANNEL       EXTI4_15_IRQn
#define RESET_KEY_IRQ_HANDLER       EXTI4_15_IRQHandler 


#define RESET_KEY_DOWN                Bit_RESET
#define RESET_KEY_UP                  Bit_SET
#define GET_RESET_KEY_STATUS()        GPIO_ReadInputDataBit(RESET_KEY_PORT, RESET_KEY_PIN)




extern void key_gpio_init(void);

#endif
