#include "main.h"

//�����ⲿ�жϳ�ʼ��
void key_gpio_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct; 
    EXTI_InitTypeDef EXTI_InitStruct;
    NVIC_InitTypeDef NVIC_InitStruct;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
    RCC_AHBPeriphClockCmd(RESET_KEY_PIN_SCK, ENABLE);
              
    GPIO_InitStruct.GPIO_Pin = RESET_KEY_PIN;      
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_Level_2;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP; 
    GPIO_Init(RESET_KEY_PORT, &GPIO_InitStruct);
    
    SYSCFG_EXTILineConfig(RESET_KEY_EXTI_PORT_SRC, RESET_KEY_EXTI_PIN_SRC);
    EXTI_ClearITPendingBit(RESET_KEY_EXTI_LINE);
    EXTI_InitStruct.EXTI_Line = RESET_KEY_EXTI_LINE;
  
    EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling; 
    EXTI_InitStruct.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStruct); 

    NVIC_InitStruct.NVIC_IRQChannel = RESET_KEY_IRQ_CHANNEL;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 0x01;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
}


/*
//�ⲿ�жϴ�������
void RESET_KEY_IRQ_HANDLER(void)
{
    if ( EXTI_GetITStatus(RESET_KEY_EXTI_LINE) != RESET )     //si4432�ж�
    {	
        //usart1_send_data(">>> reset key press >>>\n",sizeof(">>> reset key press >>>\n"));    //���ڷ�������
        EXTI_ClearITPendingBit(RESET_KEY_EXTI_LINE);
    }
}
*/



