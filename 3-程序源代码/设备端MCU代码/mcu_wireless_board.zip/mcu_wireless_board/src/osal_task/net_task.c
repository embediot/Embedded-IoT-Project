#include "main.h"


static unsigned char current_net_status = NET_STATUS_DISCONNECT;

/***********************************************************
** �� �� ��: static void master_ctrl_slave_process(unsigned char *p_data)
** ��  ����: p_data-����ָ��
** ��  ����: ��
** ��������: �������ƴӻ�ָ���
** ȫ�ֱ���: ��
** ����ģ��: ��
** ��  ����: 
** ��  ����: 
***********************************************************/
static void master_ctrl_slave_process(TYP_UN_COMMUNICATE_BUFF *p_data,unsigned int datalen)
{
    TYP_UN_COMMUNICATE_BUFF *p_data_recv = p_data;
    unsigned short uuid_value = 0;
    unsigned char info_value = 0xFF;
    unsigned char tran_flag = 0;      
    
    uuid_value = (unsigned short)((p_data_recv->Frame.data[0] << 8) | (p_data_recv->Frame.data[1]));
    info_value = p_data_recv->Frame.data[3];
    tran_flag = p_data_recv->Frame.data[2];
    
    if(info_value == BEACON_INFO)   //�������ݰ�
    {
        
    }   
    else if(info_value == RESET_SLAVE)   //��λ�ӻ�
    {
        set_default_sys_config();
        osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , IWDG_RESET_PERIOD , IWDG_RESET_PERIOD );
    }    
    else if(info_value == REBOOT_SLAVE)   //�����ӻ�
    {
        osal_start_timer( IWDG_TASK_ID , IWDG_RESET_EVENT , IWDG_RESET_PERIOD , IWDG_RESET_PERIOD );
    }
    else if(info_value == SAVE_PARAMS)    //�������
    {
        
    }
    else
    {
        
    }
   /*      
    if((uuid_value == sys_config.uuid) && (tran_flag == LOCAL_PROCESSING))    //���ǹ㲥ָ��Ҳ���͸������Ҫ�ظ��ӻ�
    {
        
    }
*/
}

static void save_slave_net_in_params(unsigned char *p_data,unsigned int datalen)
{
    sys_config.net_id = (unsigned short)((p_data[3] << 8) | (p_data[4]));
    sys_config.dev_id = (unsigned short)((p_data[5] << 8) | (p_data[6]));
    sys_config.channel = (unsigned short)((p_data[7] << 8) | (p_data[8]));
    
    save_sys_config(&sys_config);    //����Ĭ�ϲ���
}

//�л������ŵ�
static void change_working_channel(unsigned char net_status)
{
    if((net_status == NET_STATUS_PAIRING) || (net_status == NET_STATUS_UNPAIRING))
    {
        if(sys_config.dev_phy == PHY_2_4GHZ_MODULE){
            nrf24l01_write_hopping_point(NET_PAIRING_CHANNEL);
        }
        else if(sys_config.dev_phy == PHY_433MHZ_MODULE){
            si4432_convert_channel(NET_PAIRING_CHANNEL);    //�����ŵ�
        }
        else{}
    }
    else
    {
        if(sys_config.dev_phy == PHY_2_4GHZ_MODULE){
            nrf24l01_write_hopping_point(sys_config.channel);
        }
        else if(sys_config.dev_phy == PHY_433MHZ_MODULE){
            si4432_convert_channel(sys_config.channel);    //�����ŵ�
        }
        else{}
    }
}

/***********************************************************
** �� �� ��: void net_task_data_process(unsigned char *p_data,int datalen)
** ��  ����: p_data-����ָ�룬datalen-���ݳ���
** ��  ����: ��
** ��������: �������ݴ���
** ȫ�ֱ���: ��
** ����ģ��: ��
** ��  ����: 
** ��  ����: 
***********************************************************/
void net_task_data_process(unsigned char *p_data,unsigned int datalen)
{
    TYP_UN_COMMUNICATE_BUFF *p_data_recv = (TYP_UN_COMMUNICATE_BUFF *)p_data;
    
    if(check_crc(p_data_recv))        //CRC ������ȷ
    {
        switch(p_data_recv->Frame.cmd)
        {
            case CMD_SLAVE_NET_IN:   //�ӻ�����ָ��
              osal_stop_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_IN_EVENT );
              osal_stop_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_IN_TIMEOUT_EVENT );
              save_slave_net_in_params((unsigned char*)p_data_recv->Frame.data,datalen-FRAME_HEAD_LEN);
              set_net_status(NET_STATUS_CONNECT);     //����״̬Ϊ��������״̬
              change_working_channel(NET_STATUS_CONNECT); 
              osal_set_event( LED_TASK_ID, LED_TASK_START_EVENT );   //ˢ��LED״̬
            break;
            
            case CMD_SLAVE_NET_OUT:   //�ӻ�����ָ��
              osal_stop_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_OUT_EVENT );
              osal_stop_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_OUT_TIMEOUT_EVENT );
            break;
            
            case CMD_MASTER_CTRL_SLAVE:    //�������ƴӻ�ָ��
              if(p_data_recv->Frame.data[2] == UNVARNISHED_TRANSMISSION)      //͸��
              {
                  //usart2_send_package_data((unsigned char*)p_data_recv,datalen);
              }
              else if(p_data_recv->Frame.data[2] == LOCAL_PROCESSING)     //���ش���
              {
                  master_ctrl_slave_process(p_data_recv,datalen);
              }
              
            break;
            
            default:
              
              
              break;
              
              
        }
    }
    else    // CRC У��ʧ��
    {
        
    }
}



//���ʹӻ���������
static void send_slave_net_in_cmd(void)
{
    unsigned char data_len = 0;
    TYP_UN_COMMUNICATE_BUFF *p_data = NULL;
    unsigned char data_buff[20];
    
    unsigned short random_value = (unsigned short)osal_get_systick();
    
    memset(data_buff,0x00,sizeof(data_buff));
    
    //random_value
    data_buff[0] = (unsigned char)(random_value >> 8);
    data_buff[1] = (unsigned char)(random_value);
    
    //net_id
    data_buff[2] = (unsigned char)(DEFAULT_NET_ID >> 8);
    data_buff[3] = (unsigned char)(DEFAULT_NET_ID);
    
    //dev_id
    data_buff[4] = (unsigned char)(DEFAULT_DEV_ID >> 8);
    data_buff[5] = (unsigned char)(DEFAULT_DEV_ID);
    
    //dev type
    data_buff[6] = (unsigned char)(sys_config.dev_type >> 8);
    data_buff[7] = (unsigned char)(sys_config.dev_type);
        
    p_data = malloc(sizeof(TYP_UN_COMMUNICATE_BUFF));  
    
    if(p_data)
    {
        data_len = protocol_data_package(CMD_SLAVE_NET_IN,8,data_buff,p_data);         
        net_task_send_wireless_data((unsigned char*)p_data,data_len);
    }
    
    free(p_data);
    p_data = NULL;
}


//���ʹӻ���������
static void send_slave_net_out_cmd(void)
{
    unsigned char data_len = 0;
    TYP_UN_COMMUNICATE_BUFF *p_data = NULL;
    unsigned char data_buff[20];
      
    memset(data_buff,0x00,sizeof(data_buff));
      
    //net_id
    data_buff[0] = (unsigned char)(sys_config.net_id >> 8);
    data_buff[1] = (unsigned char)(sys_config.net_id);
    
    //dev_id
    data_buff[2] = (unsigned char)(sys_config.dev_id >> 8);
    data_buff[3] = (unsigned char)(sys_config.dev_id);
    
    //dev type
    data_buff[4] = (unsigned char)(sys_config.dev_type >> 8);
    data_buff[5] = (unsigned char)(sys_config.dev_type);
        
    p_data = malloc(sizeof(TYP_UN_COMMUNICATE_BUFF));  
    
    if(p_data)
    {
        data_len = protocol_data_package(CMD_SLAVE_NET_OUT,6,data_buff,p_data);         
        net_task_send_wireless_data((unsigned char*)p_data,data_len);
    }
    
    free(p_data);
    p_data = NULL;
}

/***********************************************************
** �� �� ��: uint16 net_task(uint8 task_id, uint16 events)
** ��  ����: task_id-����id��event-�¼�id
** ��  ����: events-δ�������¼�
** ��������: ϵͳ���ô˺���������net������
** ȫ�ֱ���: ��
** ����ģ��: ��
** ��  ����: 
** ��  ����: 
***********************************************************/
static uint16 net_task(uint8 task_id, uint16 events)
{
    (void)task_id; 
    
    if( events & NET_TASK_START_EVENT )    
    {      
        if((sys_config.net_id == DEFAULT_NET_ID) && (sys_config.dev_id == DEFAULT_DEV_ID))  //�豸��û�з���net_id��dev_id
        {
            set_net_status(NET_STATUS_FACTORY);     //����״̬Ϊ��������״̬
            change_working_channel(NET_STATUS_FACTORY); 
            osal_set_event( LED_TASK_ID, LED_TASK_START_EVENT );   //ˢ��LED״̬
        }
        else
        {
            set_net_status(NET_STATUS_DISCONNECT);     //����״̬Ϊ����״̬
            osal_set_event( LED_TASK_ID, LED_TASK_START_EVENT );   //ˢ��LED״̬
            change_working_channel(NET_STATUS_DISCONNECT);     
        }
        return ( events ^ NET_TASK_START_EVENT );
    }
     
    if( events & NET_TASK_FACTORY_SET_EVENT)    //�ָ����������¼�  
    {
        set_default_sys_config();               //���ó�����Ϣ
        set_net_status(NET_STATUS_FACTORY);     //����״̬Ϊ��������״̬
        change_working_channel(NET_STATUS_FACTORY); 
        osal_set_event( LED_TASK_ID, LED_TASK_START_EVENT );   //ˢ��LED״̬
        
        return ( events ^ NET_TASK_FACTORY_SET_EVENT );
    }
    
    if( events & NET_TASK_PAIR_UNPAIR_EVENT )         
    {                 
        if((sys_config.net_id == DEFAULT_NET_ID) && (sys_config.dev_id == DEFAULT_DEV_ID))  //�豸��û�з���net_id��dev_id
        {
            set_net_status(NET_STATUS_PAIRING);     //����״̬Ϊ���״̬
            osal_set_event( LED_TASK_ID, LED_TASK_START_EVENT );   //ˢ��LED״̬
            change_working_channel(NET_STATUS_PAIRING);               
            osal_start_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_IN_EVENT , NET_TASK_SLAVE_NET_IN_PERIOD , NET_TASK_SLAVE_NET_IN_PERIOD );
            osal_start_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_IN_TIMEOUT_EVENT , NET_TASK_SLAVE_NET_IN_TIMEOUT_PERIOD , 0 );
        }
        else    //�ӻ�������
        {
            set_net_status(NET_STATUS_UNPAIRING);     //����״̬Ϊ���״̬
            osal_set_event( LED_TASK_ID, LED_TASK_START_EVENT );   //ˢ��LED״̬
            change_working_channel(NET_STATUS_UNPAIRING);               
            osal_start_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_OUT_EVENT , NET_TASK_SLAVE_NET_OUT_PERIOD , NET_TASK_SLAVE_NET_OUT_PERIOD );
            osal_start_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_OUT_TIMEOUT_EVENT , NET_TASK_SLAVE_NET_OUT_TIMEOUT_PERIOD , 0 );
        }
        
        return ( events ^ NET_TASK_PAIR_UNPAIR_EVENT );
    }
    
    if( events & NET_TASK_SLAVE_NET_IN_EVENT)     //�ӻ������¼�
    {
        send_slave_net_in_cmd();
        return ( events ^ NET_TASK_SLAVE_NET_IN_EVENT);
    }
    
    if( events & NET_TASK_SLAVE_NET_IN_TIMEOUT_EVENT)
    {
        osal_stop_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_IN_EVENT );
        
        if((sys_config.net_id == DEFAULT_NET_ID) && (sys_config.dev_id == DEFAULT_DEV_ID))  //�豸��û�з���net_id��dev_id
        {
            set_net_status(NET_STATUS_FACTORY);     //����״̬Ϊ���״̬
            osal_set_event( LED_TASK_ID, LED_TASK_START_EVENT );   //ˢ��LED״̬
            change_working_channel(NET_STATUS_FACTORY);                          
        }
        else    //�ӻ�������
        {
            set_net_status(NET_STATUS_DISCONNECT);     //����״̬Ϊ����״̬
            osal_set_event( LED_TASK_ID, LED_TASK_START_EVENT );   //ˢ��LED״̬
            change_working_channel(NET_STATUS_DISCONNECT);      
        }
                     
        return ( events ^ NET_TASK_SLAVE_NET_IN_TIMEOUT_EVENT);
    }
       
    if( events & NET_TASK_SLAVE_NET_OUT_EVENT)     //�ӻ������¼�
    {
        send_slave_net_out_cmd();
        return ( events ^ NET_TASK_SLAVE_NET_OUT_EVENT);
    }
    
    if( events & NET_TASK_SLAVE_NET_OUT_TIMEOUT_EVENT)
    {
        osal_stop_timer( NET_TASK_ID , NET_TASK_SLAVE_NET_OUT_EVENT );
        
        set_net_status(NET_STATUS_DISCONNECT);     //����״̬Ϊ����״̬
        osal_set_event( LED_TASK_ID, LED_TASK_START_EVENT );   //ˢ��LED״̬
        change_working_channel(NET_STATUS_DISCONNECT); 
        
        return ( events ^ NET_TASK_SLAVE_NET_OUT_TIMEOUT_EVENT);
    }
    
    return 0;
}

//�������ݷ��ͺ���
void net_task_send_wireless_data(unsigned char *p_data,unsigned char data_len)
{
    if(sys_config.dev_phy == PHY_2_4GHZ_MODULE)
    {
        nrf24l01_send_data(p_data,(unsigned int)data_len);
    }
    else if(sys_config.dev_phy == PHY_433MHZ_MODULE)
    {
        si4432_send_data(p_data,(unsigned int)data_len);    
    }
    else
    {
        
    }
}

/***********************************************************
** �� �� ��: void net_task_init(void)
** ��  ����: ��
** ��  ����: ��
** ��������: net�����ʼ��
** ȫ�ֱ���: ��
** ����ģ��: ��
** ��  ����: 
** ��  ����: 
***********************************************************/
void net_task_init(void)
{
    register_task_array(net_task,NET_TASK_ID);

    osal_set_event( NET_TASK_ID, NET_TASK_START_EVENT );   //ˢ��LED״̬
}

unsigned char get_net_status(void)
{
    return current_net_status;
}


void set_net_status(unsigned char net_status)
{
    current_net_status = net_status;
}



