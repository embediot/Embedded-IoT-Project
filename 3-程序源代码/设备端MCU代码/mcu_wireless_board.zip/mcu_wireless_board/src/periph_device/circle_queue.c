#include "main.h"



/***********************************************************
** function    : static unsigned char  is_circlebuff_have_data(str_queue_t *p_queue)
** input       : p_queue-���ζ�������ָ��
** output      : 
** description : �ж϶����Ƿ�������
** author      :
** date        :
***********************************************************/
static unsigned char  is_circlebuff_have_data(str_queue_t *p_queue)
{
    if (p_queue->read_pos != p_queue->write_pos)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

/***********************************************************
** function    : static unsigned char  circlebuff_write_data(str_queue_t *p_queue , unsigned char data)
** input       : p_queue-��Ҫд��Ķ���ָ�룬data-��Ҫд�������
** output      : 
** description : �����д������
** author      :
** date        :
***********************************************************/
static unsigned char  circlebuff_write_data(str_queue_t *p_queue , unsigned char data)
{
    unsigned int  next_pos;
    
    next_pos = (p_queue->write_pos + 1) % MAX_BUFF_LEN;
	
    if ( next_pos != p_queue->read_pos )   
    {
        p_queue->data[p_queue->write_pos] = data;
        p_queue->write_pos = next_pos;
        return 1;
				
    }
    else
    {
        return 0;
    }
}

/***********************************************************
** function    : static unsigned char circlebuff_read_data(str_queue_t *p_queue)
** input       : p_queue-���ζ�������ָ��
** output      : 
** description : �Ӷ����ж�ȡ����
** author      :
** date        :
***********************************************************/
static unsigned char circlebuff_read_data(str_queue_t *p_queue)
{
    unsigned char data = 0;

    if (is_circlebuff_have_data(p_queue) == 1)
    {
        data = p_queue->data[p_queue->read_pos];
        p_queue->read_pos = (p_queue->read_pos + 1) % MAX_BUFF_LEN;
    }
    return  data;
}



/***********************************************************
** function    : unsigned int circlebuff_packet_datalen(str_queue_t *p_queue)
** input       : p_queue-����ָ��
** output      : 
** description : ������һ�����ݳ���
** author      :
** date        :
***********************************************************/
static unsigned int circlebuff_packet_datalen(str_queue_t *p_queue)
{
    unsigned int datalen = 0;

    if(is_circlebuff_have_data(p_queue))
    {  
        datalen = circlebuff_read_data(p_queue);    
    }

    return datalen;
}
/*******************  �ⲿ����  **************************/


/***********************************************************
** function    : void circlebuff_init(str_queue_t *p_queue)
** input       : p_queue-����ָ��
** output      : 
** description :
** author      :
** date        :
***********************************************************/
void circlebuff_init(str_queue_t *p_queue)
{
    p_queue->sem_value = 0;
    p_queue->read_pos = 0;
    p_queue->write_pos = 0;
}


/***********************************************************
** function    : void circlebuff_read_packet_data(str_queue_t *p_queue,unsigned char *p_data)
** input       : p_queue-����ָ�룬p_data-Ҫ���������ָ��
** output      : 
** description : �Ӷ������ȡһ������
** author      :
** date        :
***********************************************************/
unsigned int circlebuff_read_packet_data(str_queue_t *p_queue,unsigned char *p_data)
{
    unsigned char i = 0;
    unsigned int len = 0;
    
    len = circlebuff_packet_datalen(p_queue);
      
    if(len)
    {		 		
        for(i=0;i<len;i++)
        {
            p_data[i] = circlebuff_read_data(p_queue);
        }	
        
        p_queue->sem_value -= 1;
    } 
        
    return len;
}

/***********************************************************
** function    : unsigned char circlebuff_write_packet_data(str_queue_t *p_queue,unsigned char *s, unsigned int len)
** input       : p_queue-����ָ�룬s-Ҫ���������ָ�룬len-д�볤��
** output      : 
** description : ������д��һ������
** author      :
** date        :
***********************************************************/
unsigned char circlebuff_write_packet_data(str_queue_t *p_queue,unsigned char *s, unsigned int len)
{
    unsigned char i = 0;

    circlebuff_write_data(p_queue,len);  

    for (i=0; i<len; i++)
    {
        circlebuff_write_data(p_queue,s[i]);  
    }
		
    if(i == len)
    {
        p_queue->sem_value += 1;
        return 1;
    }
    else return 0;
}
